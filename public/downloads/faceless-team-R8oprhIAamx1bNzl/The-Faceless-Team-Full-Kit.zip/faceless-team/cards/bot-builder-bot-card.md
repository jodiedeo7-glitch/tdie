# Bot Builder Bot · Quick Card

## What it does
Turns something you already do well into a bot of your own:
1. Helps you choose the right task
2. Interviews you so the bot works your way
3. Writes the bot and a self-check for it
4. Tests it on real examples
5. Packages it as one file and writes your buyer's Start Here page
6. Helps you write the listing if you are selling it

## First five things to ask it
1. "I want to build my own bot."
2. "Help me find a task that would make a good bot."
3. "Turn this checklist into a bot." (paste it)
4. "Package my bot." 
5. "Write the listing for my bot."

## Good to know
- One bot does one job.
- Build from something you do often and do well.
- The real test is a brand-new chat, then one other person trying it without help.
- Only your own method and material goes in. Nothing from someone else's paid product.
- Read BUILD-AND-SELL-YOUR-OWN-BOT.md for the whole method in one place.
