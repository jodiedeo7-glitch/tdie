# Community Bot · Quick Card

## What it does
Keeps your group useful and alive without turning it into an advert:
1. Plans your week in teach, value and sell slots
2. Writes every post in your voice
3. Drafts replies to member comments for you to approve
4. Writes check-ins for members who have gone quiet
5. Turns anything new in your community into posts

## First five things to ask it
1. "Plan and write my week of community posts."
2. "Draft replies to these comments." (paste them)
3. "Write check-ins for these quiet members." (paste names and anything you know)
4. "I added something new to my group. Turn it into posts."
5. "Suggest a weekly ritual thread for my group."

## Good to know
- Everything is a draft. It never posts or replies for you.
- Teach comes first and sell comes last. Most days have no sell post.
- It never invents a member win, a number or a deadline.
- Complaints and refund requests are handed back to you with a first line only.
- Tell it what members asked this week. Real questions make the best posts.
