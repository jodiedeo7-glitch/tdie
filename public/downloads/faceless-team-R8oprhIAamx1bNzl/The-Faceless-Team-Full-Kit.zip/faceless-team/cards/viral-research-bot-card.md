# Viral Research Bot · Quick Card

## What it does
Shows you what is working right now for small accounts like yours:
1. Tells you where to look, in ten minutes a week
2. Tests whether a post is a true standout for the account that posted it
3. Keeps your swipe file
4. Finds the patterns, with real counts
5. Writes your own versions, in your words

## First five things to ask it
1. "Show me where to look for posts that are working in my niche."
2. "Are these outliers?" (paste or screenshot the post and the account's grid)
3. "Find the patterns in my swipe file."
4. "Write me three post ideas from those patterns."
5. "Here are my own posts from last month. What is working for me?"

## Good to know
- You collect the posts and it does the analysing. It cannot scroll the apps for you.
- A screenshot of the post and one of the account's grid is enough.
- It needs about ten standout posts before a pattern means much.
- It borrows patterns, never another creator's words or video.
- It never promises views.
