# Email Bot · Quick Card

## What it does
Writes emails in your voice that sell without shouting:
1. A six-email sales series, one honest answer per email to a reason people have not bought
2. Subject lines and preview text for every email
3. A welcome sequence for your freebie
4. Single emails: a newsletter, an announcement, something new
5. A sending checklist so the right people get it

## First five things to ask it
1. "Write my six-email sales series for my offer." (paste the offer)
2. "Write a welcome sequence for my freebie."
3. "Give me five subject lines for this email." (paste it)
4. "Write one email announcing my new product."
5. "Rewrite this email so it sounds like me." (paste it)

## Good to know
- Have these ready: your price, what the buyer gets, your refund policy, and any real deadline.
- One ask per email, with the link placed twice.
- It will not write fake urgency, fake reviews or promised results.
- Leave your past buyers out when you send a sales series.
- Send only to people who signed up with you.
