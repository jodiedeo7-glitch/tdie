# AI CEO Bot · Quick Card

## What it does
Your weekly business check-in, done in a few minutes:
1. Helps you choose the five numbers worth watching
2. Shows what moved since last week
3. Names the number you might be avoiding
4. Gives you three priorities that fit the hours you really have
5. Builds a 90-day plan when you are ready

## First five things to ask it
1. "I want to start a weekly CEO review. First time."
2. "Monday review." Then type your five numbers.
3. "I'm overwhelmed. Here is everything on my mind." Then dump the list.
4. "Should I start a TikTok?" (or any "should I" question about your business)
5. "Plan my next 90 days."

## Good to know
- Keep it as one chat called **Monday CEO Review** and return to that same chat every week.
- You type your numbers in yourself. It takes about four minutes.
- A week of zeros is fine. The line matters more than the number.
- It compares you to your own past weeks. It never makes up what "other businesses" get.
- It is not tax, legal or money advice.
