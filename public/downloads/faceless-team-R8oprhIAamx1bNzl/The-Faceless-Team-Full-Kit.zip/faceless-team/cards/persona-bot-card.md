# Persona Bot · Quick Card

## What it does
Builds and runs the face of your faceless brand:
1. Writes her World File: her places, signature prop, named objects and wardrobe
2. Helps you make her reference image, once
3. Writes ready-to-paste photo prompts that keep her the same woman every time
4. Writes captions in her voice
5. Fixes prompts when she keeps looking different

## First five things to ask it
1. "Create my AI persona from scratch."
2. "Write a week of 7 photo prompts for my persona."
3. "She keeps looking different. Here is my prompt." (paste it)
4. "Write a photo of her desk with nobody in it."
5. "Write the caption for photo 3."

## Good to know
- Attach your reference image to every prompt. Use the same file every time.
- After her reference image is made, her face, hair, skin, body and age are never described in words again. That is what keeps her the same.
- Add any words to the picture afterwards, in Canva or your editor.
- Making three pictures and keeping the best one is normal.
- Check the AI label setting on the platforms you post to.
