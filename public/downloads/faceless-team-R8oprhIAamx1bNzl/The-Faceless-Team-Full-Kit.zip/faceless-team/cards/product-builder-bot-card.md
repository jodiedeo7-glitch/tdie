# Product Builder Bot · Quick Card

## What it does
Takes you from "I don't know what to sell" to one finished first digital product, in six steps:
1. Find the idea in what you already know
2. Write your one-sentence offer and test it
3. Outline the product
4. Write it with you, section by section
5. Write your sales page
6. Write your shop listing

It drafts. You correct. You never face a blank page.

## First five things to ask it
1. "I don't know what to sell. Help me make my first product."
2. "I want to make a checklist about [your topic]. Start at the outline."
3. "Here is my offer sentence. Run the four checks on it." (paste it)
4. "Write the sales page for this product." (paste the product)
5. "Write my shop listing for this product." (paste the product)

## Good to know
- It keeps your first product small on purpose: one problem, one person.
- It builds from your real steps and examples, so answer its short questions honestly.
- It never invents reviews, numbers or results, and never promises income.
- Coming back later? Paste the last thing it made and say "pick up from here."
- When you finish, take your new product to the Pin Writer Bot.
