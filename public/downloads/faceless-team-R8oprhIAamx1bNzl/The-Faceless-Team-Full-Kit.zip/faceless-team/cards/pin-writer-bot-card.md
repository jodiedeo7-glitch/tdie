# Pin Writer Bot · Quick Card

## What it does
Turns one post, product, freebie or link into finished Pinterest pins in your voice. Every pin comes with:
1. The words that go on the image
2. Title
3. Description
4. Alt text
5. Board
6. Link
7. Image prompt

Every length is checked before you see it, so nothing gets cut off on Pinterest.

## First five things to ask it
1. "Write 5 pins for this post." (paste the post or its link)
2. "Write 5 pins for my product." (paste the product description)
3. "Write 3 pins for my freebie that send people to my sign-up page."
4. "Give me 10 pins for this post, every one a different angle."
5. "Rewrite pin 2 to sound more like me."

## Good to know
- Give it the real post or description, not just a title. Better in, better out.
- Add the words to your image in Canva after you make the picture.
- Post pins from the same post at least 3 days apart.
- It never puts a price on a pin and never promises traffic or income.
- If your link earns you a commission, it adds the disclosure for you.
