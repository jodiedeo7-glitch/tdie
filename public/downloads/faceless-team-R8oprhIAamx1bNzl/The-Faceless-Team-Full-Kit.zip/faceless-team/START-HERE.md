# The Faceless Team · Start Here

Your whole team: the one-time setup plus eight bots. Set up once, about ten minutes.

## Step 1 · Turn on one setting (one time)
1. Open Claude.
2. Go to **Settings**, then **Capabilities**.
3. Turn on **Code execution and file creation**.

## Step 2 · Add your bots
Do this once for each of the nine files ending in `.skill`:
1. Go to **Customize**, then **Skills**.
2. Click the **+** button, then **Create skill**, then **Upload a skill**.
3. Choose the file. It appears in your list. Make sure its switch is on.

The nine files:
- `faceless-team-setup.skill`
- `pin-writer-bot.skill`
- `product-builder-bot.skill`
- `ai-ceo-bot.skill`
- `persona-bot.skill`
- `community-bot.skill`
- `email-bot.skill`
- `viral-research-bot.skill`
- `bot-builder-bot.skill`

## Step 3 · Make one home for your team
1. Click **Projects**, then **New project**.
2. Name it **My Faceless Team**.
3. Open the project's instructions box and paste everything from the file `PROJECT-INSTRUCTIONS.txt`.

One project holds the whole team, so a free Claude account has room for it.

## Step 4 · Run your setup
1. Start a chat inside **My Faceless Team**.
2. Type: **set up my team**
3. Answer by typing numbers. It takes about five minutes.
4. It hands you a file called `MY_BRAND_FILE.md`. Add that file to the project's knowledge.

Every bot now reads that file before it writes a word, which is why they all sound like you.

## Step 5 · Use a bot
Inside **My Faceless Team**, type what you want in plain words:
- "Write 5 pins for this post" and paste the post or its link.
- "I don't know what to sell. Help me make my first product."
- "Monday review" and type your five numbers. Keep this one as its own chat, named **Monday CEO Review**, and come back to it every week.
- "Create my AI persona" or "Write a week of photo prompts for my persona."
- "Plan and write my week of community posts."
- "Write my six-email sales series for my offer."
- "Are these posts outliers?" and paste what you found.
- "I want to build my own bot."

To change anything about your brand later, type: **update my brand file**
