
**I didn't use "make money online" in these pins.** Two reasons. Pinterest's spam filter penalises that exact phrase, so pins that use it tend to get shown less. And your brand file says never to promise a result. On a planner, "make money online" reads like the planner makes you money, which it doesn't. Instead, the pins use "side business" and "side hustle". People search those words too, and they describe the planner honestly. If you still want the phrase, tell me and I'll put it in.

I also left the $19 price off. Pins stay up for years and prices change.

---

**PIN 1 · The single tip**
Words on the image: My 20-Minute Sunday Reset
Title: Sunday reset routine for a side business: the 20-minute digital planner page I use weekly
Description: Sunday reset routine for a side business, minus the three-hour vision board. Nobody is coming to organise your week. Fine. I open the weekly reset page in this iPad planner every Sunday, plan the week, and move on with my life. It also has a habit tracker, a content calendar and a side-business income tracker, so the whole thing lives in one place instead of six apps. Handy for anyone running a side hustle from their phone and a dream. (affiliate link)
Alt text: A woman in an oversized cream sweater sits cross-legged on a sofa in soft morning light, writing on an iPad with a stylus, a mug of coffee beside her on a wooden side table.
Board: Sunday Reset Routine Ideas
Link: https://example.com/sasha-planner-link
Image prompt: Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. Vertical 2:3 photograph. She sits cross-legged on a sofa in a calm living room, wearing an oversized warm cream knit sweater, hair in a loose low bun, writing on an iPad with a stylus. A mug of coffee sits on a wooden side table beside her. Soft morning window light from the left. Eye-level camera angle, slightly to the side. Colours: warm cream, soft sage green, natural oak. Clear, uncluttered space across the top third for a headline to be added later. Realistic, natural, not staged or plastic. No text, letters, logos or watermarks anywhere in the image, including on the iPad screen.
*Attach your reference image. Add the words in Canva or your editor after you make the image.*

**PIN 2 · The time saver**
Words on the image: Plan TikToks in One Place
Title: How to plan your TikTok content for a side hustle without opening five different apps
Description: How to plan your TikTok content for a side hustle when your ideas currently live in your notes app, three screenshots and your head. I use the content calendar in this digital planner for every TikTok I post. One page, one week, done. It sits next to a habit tracker, a weekly reset page and a side-business income tracker, so planning content and tracking the business happen in the same spot. Works on iPad. No more posting whatever. (affiliate link)
Alt text: Overhead view of an iPad on a pale wooden desk showing a weekly planner grid, with a phone on a small tripod, a stylus and a cup of iced coffee arranged around it in bright daylight.
Board: TikTok Content Planning for Beginners
Link: https://example.com/sasha-planner-link
Image prompt: Vertical 2:3 photograph. Overhead flat lay on a pale natural wooden desk: an iPad showing a blank weekly planner grid with empty boxes, a phone on a small tripod, a white stylus and a glass of iced coffee. Bright, even daylight from a nearby window. Camera directly overhead. Colours: warm cream, saturated terracotta orange (never pale), soft sage green. No people. Clear, uncluttered space across the bottom third for a headline to be added later. Realistic, natural, not staged or plastic. No text, letters, logos or watermarks anywhere in the image, including on the iPad and phone screens.
*Add the words in Canva or your editor after you make the image.*

**PIN 3 · The look inside**
Words on the image: Side Business Planner Pages
Title: Digital planner for a side business: what is inside, page by page, and what I use each one for
Description: Digital planner for a side business, and what is actually inside it. One: a weekly reset page I fill in every Sunday. Two: a habit tracker. Three: a content calendar, which is where my TikToks get planned. Four: a side-business income tracker, so the numbers stop living on the back of a receipt. It is an iPad planner, so it goes wherever you go. Not magic, sorry. Just one tidy place to run the whole week from, on the iPad you already own. (affiliate link)
Alt text: A woman in a soft lavender cardigan sits at a cafe table by a large window, scrolling through pages of a digital planner on an iPad, a stylus in her other hand and a latte beside her.
Board: Side Hustle Planner and Organisation
Link: https://example.com/sasha-planner-link
Image prompt: Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. Vertical 2:3 photograph. She sits at a small round cafe table beside a large window, wearing a lavender cardigan (clearly purple, never grey) over a white top, hair down and tucked behind one ear. She scrolls an iPad with one hand and holds a stylus in the other. A latte sits on the table. Soft, diffused daylight through the window. Camera slightly above eye level, angled down towards the table. Colours: lavender, warm cream, light oak. Clear, uncluttered space across the top third for a headline to be added later. Realistic, natural, not staged or plastic. No text, letters, logos or watermarks anywhere in the image, including on the iPad screen.
*Attach your reference image. Add the words in Canva or your editor after you make the image.*

---

**Boards:** You don't have any boards yet, so these three names are suggestions for you to create. Each one is written the way people search.

**Posting note:** Post Pin 1 first, on a Saturday or Sunday, because it's about Sunday planning. Post Pin 2 at least 3 days later and Pin 3 at least 3 days after that. Pins about the same product should never go out on the same day.

**One thing I noticed:** Your link is still the placeholder (example.com/sasha-planner-link). Swap in your real affiliate link before you post, or all three pins will lead nowhere.

All three pins passed the length checker. A spreadsheet of the batch is saved at `sunday-reset-planner-pins.csv` for your pin library.

