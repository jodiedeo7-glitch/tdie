## She typed: I don't know what to sell. Help me make my first product.

**Step 1 of 6 · Find the idea**

Your first product only needs to solve one problem for one person. You already know enough to make it. These three questions will show me what that is.

**1. What do people already ask you for help with?**
Type a few things, even small ones like "how do you meal prep" or "can you look at my resume."
Or reply **1** if nobody asks you for anything.

**2. What have you figured out the hard way in the last few years?** Pick any that fit:
1. A job skill
2. Parenting or home
3. Money or budgeting
4. A health or fitness routine
5. A hobby or craft
6. Running a small business
7. A tool or app you know well
8. Something else (type it)

**3. Who was struggling with that before it got figured out?**
1. Me, a few years ago
2. Someone I know (who?)

Short answers are fine, like "2, 7, Canva, people always ask me how I make my graphics, 1." Once you answer, I'll give you three product ideas, score each one, and tell you which I'd make first.

## She answered the three questions

**Step 1 of 6 · Find the idea**

You've got two real things here. People already come to you with both, and two years ago you were the parent who needed them. Here are three ideas, each scored on three things: can you make it from what you already know, do buyers have this problem right now, and can it be finished in days.

**1. The Potty Training Week Plan** (planner, about 8 pages)
- **For:** parents about to start potty training who are dreading it
- **Problem it removes:** not knowing what to do on day 1, day 2, day 3, or what to do when it goes sideways
- **Inside:** a get-ready checklist, a day-by-day plan, a daily accident and win tracker, and "what I did when..." fixes
- **Score:**
  - You know it: ✅ You did it and people ask you how.
  - Problem right now: ✅ Parents usually have a deadline, like daycare or a new baby, so they look for help the week they start.
  - Days, not months: ✅

**2. The Toddler Nap Routine Checklist** (checklist, 2 to 3 pages)
- **For:** parents whose toddler fights every nap
- **Problem it removes:** guessing what to do before nap, in what order, every single day
- **Score:**
  - You know it: ✅
  - Problem right now: ✅
  - Days, not months: ✅ This is the fastest to finish.

**3. The Nap Strike Cheat Sheet** (1 to 2 pages)
- **For:** parents whose toddler suddenly refuses naps, wakes after 30 minutes, or is dropping a nap
- **Problem it removes:** panicking and trying everything at once
- **Score:**
  - You know it: ✅
  - Problem right now: ⚠️ It's real but comes and goes, so fewer people are searching at any given moment.
  - Days, not months: ✅

**I'd make #1, the Potty Training Week Plan.** Parents start potty training on a set date, so they're ready to buy right then. A planner also feels worth paying for in a way a single page doesn't. Your nap knowledge can become product #2 later.

There's one wording rule I'll keep for you. We'll sell it as **a 7-day plan**, the one you followed. We won't promise their child will be trained in a week. Every child is different, and Etsy and other shops act on result promises. It will also carry a one-line note that this is your experience, not medical advice.

**Which one do you want to make?**
1. Potty Training Week Plan
2. Toddler Nap Routine Checklist
3. Nap Strike Cheat Sheet
4. Something else (type it)


## She said: go with whichever you recommend

**Step 2 of 6 · The one-sentence offer**

We're making the **Potty Training Week Plan**. Before writing anything else, we need the one sentence that says what it does. That sentence becomes the first line of your sales page, your shop bio and your link-in-bio.

It has three parts, in this order: **who the buyer is**, **what she walks away with**, and **what it costs her to get there**. Here are three versions, each run through four checks.

---

**Version 1**
> Parents about to potty train know exactly what to do each day, without reading ten conflicting blogs first.

- Who: parents about to potty train. Walks away with: knowing what to do each day. Costs her: no blog rabbit hole.
- Starts with the buyer: ✅ Pass
- No format or length in it: ✅ Pass
- No price: ✅ Pass
- Easy to repeat from memory: ✅ Pass

---

**Version 2**
> Parents dreading potty training get a calm day-by-day plan to follow, so accidents stop feeling like failures.

- Starts with the buyer: ✅ Pass
- No format or length in it: ✅ Pass
- No price: ✅ Pass
- Easy to repeat from memory: ✅ Pass
- ⚠️ **It's missing the third part.** It never says what it saves her. It's also starting to sell the container: "a plan to follow" describes the thing she gets, not where she ends up.

---

**Version 3**
> Toddler parents start potty training knowing what to do on day one, day three and every accident in between, with no googling while holding a wet kid.

- Starts with the buyer: ✅ Pass
- No format or length in it: ✅ Pass
- No price: ✅ Pass
- Easy to repeat from memory: ❌ Fail. It's too long. I like the wet-kid line, though, so we'll save it for the sales page.

---

**I recommend Version 1.** It passes all four checks, has all three parts, and you could say it to a friend at the park. It also describes knowing what to do, not a promise that the child will be trained, so it stays clear of result claims.

The second sentence underneath it will say what the product actually is:
> It's the 7-day plan I followed: a get-ready checklist, a day-by-day guide, a daily tracker and what I did when things went sideways.

**Keep it?**
1. Keep Version 1
2. Use Version 2 or 3 instead
3. Change a word (tell me which)

