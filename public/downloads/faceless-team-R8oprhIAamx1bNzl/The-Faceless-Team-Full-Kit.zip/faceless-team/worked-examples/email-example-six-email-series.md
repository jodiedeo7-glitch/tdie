## The six-email sales series for a 14 dollar printable planner.
EMAIL 1 · SEND DAY 1 · "I don't have time"
SUBJECT: The house reset for women with no spare day
PREVIEW: You don't need a free Saturday. You need to know which room is next.

If your house only gets a proper reset in your head, this one's for you.

Most of us don't skip it because we don't care. We skip it because a reset looks like a whole day, and nobody has a whole day. That part is true. You probably don't have one either.

Here's what makes the difference: a reset doesn't have to happen all at once. When every room has its own short list, you can do the kitchen one evening and the bathroom another, and you never lose your place. 🧺

That's what the Whole House Reset Planner ($14) is built around. Before you decide anything, [have a look inside the planner](https://example.com/planner-preview) and see the pages for yourself.

What's inside:
- room-by-room reset lists, so you always know where you left off
- a 15-minute daily page for the days when that's all there is
- a laundry page, because laundry is its own room in most houses
- a one-room version if you live in an apartment

It's a 22-page printable PDF, and you get it instantly. Print the pages you need and start with whichever room is bothering you most.

The easiest way to know if it suits your days is to [flip through the preview pages](https://example.com/planner-preview). No pressure at all.

Talk soon,
Tidy Little Wins

P.S. Next time: who this planner is really for, and who I'd tell to skip it.

===

EMAIL 2 · SEND DAY 3 · "Is this for someone like me?"
SUBJECT: Big house, small flat, or somewhere between?
PREVIEW: Who the Whole House Reset Planner is for, and who should skip it.

If you've ever looked at a cleaning planner and thought "that's for someone with a bigger house, or more time, or a tidier life than mine," this one's for you.

Fair enough. A lot of planners are made for a home that doesn't look like yours.

So let me tell you exactly who I made the Whole House Reset Planner ($14) for. 🏡

She's a busy mom. Her home gets messy faster than it gets tidy. She isn't chasing a perfect house, she wants a calmer one. And she's tired of carrying the whole to-do list around in her head.

Her home might be a family house with a laundry pile that never ends. It might be a small apartment. That's why there are two ways to use it: the room-by-room reset lists for a whole house, and a one-room version for apartments.

If that sounds like you, [see everything inside the Whole House Reset Planner](https://example.com/planner).

And who should skip it?
- If you already have a cleaning routine that works and you stick to it, keep doing what works. You don't need this.
- If you'd rather not print anything, this is a printable PDF, so it won't suit you.
- If you're hoping for someone to do the cleaning for you, I can't help there. This is paper, not a person.

Still here? Then it was probably made with you in mind. [Get the planner for $14](https://example.com/planner) and it's yours instantly.

Talk soon,
Tidy Little Wins

P.S. Next time I'm answering the honest one: "Can't I just make my own list for free?"

===

EMAIL 3 · SEND DAY 5 · "I can do this myself for free" (the money email)
SUBJECT: Yes, you could make your own cleaning list
PREVIEW: Honestly, you could. Here's what the $14 buys you instead.

If you've thought "I could just write my own checklist," this one's for you.

You're right. You could. There are free lists everywhere, and you know your home better than anyone.

But the list was never really the hard part. The hard part is deciding what goes on it, room by room, then keeping it somewhere you'll actually find it, then working out what to do on the days you only have a few minutes.

That's the part the Whole House Reset Planner ($14) has already done for you. ✨ [See what's inside the planner](https://example.com/planner).

Here's exactly what you're paying for:
- 22 printable pages, ready the moment you order
- room-by-room reset lists, already written
- a one-room version for apartments
- a laundry page
- a 15-minute daily page for the short days

The price is $14, paid once. There's no payment plan and nothing monthly.

If you'd rather build your own, I mean it, go for it. And if $14 isn't right for you this month, that's completely fine. The planner will still be here.

But if you'd like to skip the evening of making it and just start, [get the Whole House Reset Planner for $14](https://example.com/planner).

Talk soon,
Tidy Little Wins

P.S. Next time: the one thing I want you to know before you buy.

===

EMAIL 4 · SEND DAY 7 · "What if it isn't what I think it is?"
SUBJECT: Before you buy: there are no refunds
PREVIEW: So I'd rather you see every kind of page first. Here's how.

If you've ever bought a printable and felt let down the second you opened it, this one's for you.

That feeling is real, and I don't want you to have it with me.

So here's the plain truth: **the Whole House Reset Planner ($14) is an instant download, and I don't offer refunds.**

Because of that, I'd much rather you know exactly what you're getting before you pay. That's why there's a preview. [Look inside the planner first](https://example.com/planner-preview), and take your time with it. 🤍

Here's what you'll see in the full 22-page printable PDF:
- room-by-room reset lists
- a one-room version for apartments
- a laundry page
- a 15-minute daily page

I'll be honest about one more thing too: the planner is new, so I don't have buyer reviews to show you yet. The preview is the best way I have to show you what's inside, and I'd rather give you that than tell you what other people think.

If the pages look like they'd help your home feel calmer, you'll know. And if they don't, you've lost nothing by looking. [Open the preview here](https://example.com/planner-preview).

Talk soon,
Tidy Little Wins

P.S. Next time: for anyone with a drawer of planners they never finished.

===

EMAIL 5 · SEND DAY 9 · "I've bought planners before and never used them"
SUBJECT: For the woman with three unused planners
PREVIEW: Why this one is built around rooms instead of a perfect week.

If you've got a drawer with a few half-filled planners in it, this one's for you.

No judgement here. Most planners ask you to keep up with them every day, and the first busy week breaks the streak. After that, it's hard to pick back up.

The Whole House Reset Planner ($14) works differently, and here's the concrete part:
- It's organised by room, not by week. Miss a few days and you simply start with whichever room is next. There's no streak to break.
- There's a 15-minute daily page for the days when a full room isn't happening.
- Laundry has its own page, so it stops swallowing everything else.
- If you're in an apartment, there's a one-room version.

I can't promise you'll never put it down. Nobody can. But when you pick it up again, it's built to let you start right where you are. 🌿 [See how the planner is laid out](https://example.com/planner).

Who should skip it: if you're looking for a meal planner, a budget planner or a daily habit tracker, this isn't that. It's a cleaning and reset planner for your home, and that's all it tries to be.

If that's exactly what you need, [get the Whole House Reset Planner for $14](https://example.com/planner). It's a 22-page printable PDF and you get it instantly.

Talk soon,
Tidy Little Wins

P.S. Tomorrow's the last one in this little series, and it's about "I'll do it later."

===

EMAIL 6 · SEND DAY 10 · "I'll do it later"
SUBJECT: There's no deadline on this one
PREVIEW: Nothing is ending. Here's the only honest reason not to wait.

If you've been meaning to sort the house out "when things calm down," this one's for you.

I get it. Later feels sensible. And I'm not going to pretend otherwise: there's no sale ending, no bonus disappearing, no countdown.

So here's the only honest reason not to wait. Every week the reset stays "later," it stays in your head. The list of rooms, the laundry, the thing you keep meaning to get to. Carrying that around is tiring, even on the days you don't touch a single thing.

The Whole House Reset Planner ($14) takes that list out of your head and puts it on paper, room by room. You get it instantly, print the pages you need, and start with one room tonight if you like. Or just the 15-minute daily page. 💛

If now feels right, [get the Whole House Reset Planner here](https://example.com/planner).

And if it doesn't, that's okay too. Later is allowed. But if a little more calm at home sounds good this week, [the planner is ready when you are](https://example.com/planner).

Talk soon,
Tidy Little Wins
