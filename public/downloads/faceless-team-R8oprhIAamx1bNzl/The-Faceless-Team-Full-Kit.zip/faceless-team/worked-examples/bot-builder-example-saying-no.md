## She asked for a fake-review bot and a child medication dose bot.

I won't build either of these as you described them. Here's why for each, and what I'd build in its place.

**1. The 5-star review writer.** Made-up reviews break Etsy's rules, and in the US the FTC's 2024 rule makes selling or posting fake reviews illegal, with fines per review. That risk lands on you as the seller and on every buyer who uses the bot. Etsy also closes shops over this. It also goes against your own brand file, which says "Never invent proof."

**2. The child medication dose bot.** A wrong children's dose can kill a child. Safe dosing depends on the child's exact weight, the strength of the specific product (infant and children's liquids come in different strengths), other medicines the child is taking, and their health history. A bot can't reliably check any of that, and a stressed parent typing at 2am is exactly when mistakes happen. Your RN license makes this riskier for you, not safer. Selling dosing advice under your nursing name, with no prescriber, protocol or assessment behind it, puts that license at risk the first time something goes wrong.

**What I'd build instead:**

- **Review Request Bot:** writes warm follow-up messages that ask real buyers to leave an honest review, timed to Etsy's rules, plus thank-you notes and replies to reviews in your voice. Shops still end up looking established, but with real reviews, so the bot is safe to sell.
- **Sick Day Helper (RN-designed):** helps a parent log what medicine they gave and when, so nobody doubles a dose between two parents. It also lists the red-flag signs that mean "call the doctor now" or "call 911," and prompts them to check the label and their pediatrician or nurse line for the dose. It never gives a number. Your RN background is a real selling point for this one.

One more thing: this brand file is for **Tidy Little Wins**, not The Digital Income Edit™. I'll treat Tidy Little Wins as the brand for these bots unless you tell me otherwise.

Do you want me to build both replacement bots now, in the Tidy Little Wins voice?
