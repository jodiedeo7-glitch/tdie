## She asked for a week of posts for her Facebook group, one post a day.

Here's your week for the Facebook group: one post a day, all written out. I ran the plan through the posting-rules checker and it passed: 4 Teach posts, 2 Value posts and 1 Sell post. Nothing repeats your entryway or Sunday-reset posts from the last two weeks.

**Your weekly ritual thread:** "Little Wins Friday." Every Friday, members share one small tidy win from their week. It fits your brand name, the bar to join in is low, and the wording stays the same each week so people learn to show up for it.

**The week**

| Day | Slot | Post | Offer |
|---|---|---|---|
| Mon | Teach | A routine for night-shift weeks | none |
| Tue | Teach | The one-load rule for laundry | none |
| Wed | Value | Free 10-minute tidy checklist | free checklist |
| Thu | Teach | Clear one surface before bed | none |
| Fri | Value | Little Wins Friday (ritual thread) | none |
| Sat | Sell | The planner now has a laundry page | Whole House Reset Planner, $14 |
| Sun | Teach | The one-basket sweep | none |

Facebook shows posts with links to fewer people, so the links go in the first comment and each post points people there.

---

```
MON · TEACH
Title: A routine for night-shift weeks

Post:
"How do I keep a routine when I work nights?"

One of you asked this, and I bet you're not the only one 💛

Here's the shift: tie your routine to when you wake up, not to the clock.

So "morning tidy" doesn't have to mean 8am. It's the first 10 minutes after you get up, whether that's 7am or 3pm.

Try this today:
→ Pick ONE small job for right after you wake up (empty the dishwasher, wipe the counter, start a load)
→ Pick ONE for right before you sleep (clear the sink, set out tomorrow's things)

That's it. Two anchors, whatever your hours look like.

Where it usually goes wrong: trying to copy a 9-to-5 routine onto a night-shift body. It won't fit, and that isn't your fault.

If you work nights or odd hours, tell me your shift below and I'll help you pick your two anchors.

Link: none
```

```
TUE · TEACH
Title: The one-load rule for laundry

Post:
The laundry mountain doesn't come from too much laundry. It comes from loads that start and never finish.

Today's tiny rule: one load, all the way through.

Wash → dry → fold → put away. Don't start a second load until the first one is back in the drawers.

It feels slower. It isn't. The pile on the chair stops growing.

The step that usually gets skipped is "put away." Folded clothes sitting in a basket are still laundry 🧺

Which step do you get stuck on: washing, drying, folding or putting away? Tell me below.

Link: none
```

```
WED · VALUE (free resource)
Title: Free 10-minute tidy checklist

Post:
For the days when you've got ten minutes and no idea where to start ✨

My 10-Minute Tidy Checklist is free. It's one page that walks you round the house in order, so you don't have to decide anything.

It's for you if the mess feels too big to begin, or if you just want a quick reset before someone comes over.

When you're done, you'll have one calmer room and a list you can use again tomorrow.

The link is in the first comment 👇

Link (first comment): Grab the free 10-minute tidy checklist here → https://example.com/free-tidy
```

```
THU · TEACH
Title: Clear one surface before bed

Post:
Waking up to a cluttered kitchen counter makes the whole day feel behind before it starts.

Tonight, try just this: clear one surface before bed.

Not the whole kitchen. Just one surface: the counter by the kettle, the dining table or your nightstand.

Put things back where they live, wipe it down, done. Usually under five minutes.

A tip: pick the surface you see first when you wake up. That's the one that sets the tone for your day.

Which surface are you choosing tonight? Tell me below and I'll check in tomorrow 💛

Link: none
```

```
FRI · VALUE (ritual thread)
Title: Little Wins Friday 🌼

Post:
It's Little Wins Friday 🌼

Share one small tidy win from this week. Small counts. Small is the whole point.

A cleared counter. One load put away. Ten minutes you didn't think you'd find.

Two rules:
1. Every win counts, however small.
2. Cheer on two other people before you go.

What's your little win this week?

Link: none
```

```
SAT · SELL
Title: The planner now has a laundry page

Post:
After Tuesday's post, a few of you said laundry is where your week falls apart.

So I added a laundry page to the Whole House Reset Planner 🧺

The Whole House Reset Planner is a printable planner to help you keep your home calm without starting from scratch every week. It now includes the new laundry page for tracking your loads all the way through to put away.

It's $14.

If you already have a system that works for you, keep using it. That's the goal anyway.

If you'd like everything in one place, the link is in the first comment 👇

Link (first comment): Get the Whole House Reset Planner here → https://example.com/planner
```

```
SUN · TEACH
Title: The one-basket sweep

Post:
When stuff is scattered across every room, tidying feels like a job with no end.

Try the one-basket sweep:

→ Grab one basket
→ Walk through the main room and pick up anything that doesn't live there
→ Then walk the basket round the house and drop each thing back in its spot

One trip in, one trip out. No zig-zagging back and forth with one sock in your hand 😅

The catch: the basket has to be empty by the end. If it turns into a new junk pile, the mess has just moved.

What always ends up in your basket? Tell me below. I'm curious what turns up most.

Link: none
```

---

Two things you might want to change:
- **Saturday's post** says "a few of you said laundry is where your week falls apart." I wrote that because Tuesday asks people where they get stuck with laundry. If that doesn't happen, open the post with "I just added a laundry page to the Whole House Reset Planner" instead, so nothing in it is made up.
- To save your setup for next time (Facebook group, one post a day, most members don't own the planner, Little Wins Friday), say **"add this to my brand file."**

These are drafts. I haven't posted anything.

