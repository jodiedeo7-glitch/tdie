## She asked: is 2 percent good, what do other shops get, and should I start a TikTok?

**Monday review: week of 2026-11-09**

**What moved**
- Money in: 88, down from 90 (−2). Down two weeks running.
- Email subscribers: 249, up from 241 (+8).
- New buyers: 5, down from 6 (−1). Down two weeks running.
- Freebie downloads: 11, down from 17 (−6, −35%).
- Things published: 9, up from 8 (+1).

**Biggest mover: freebie downloads.** They've fallen every week since you started logging: 31, then 24, 17, and now 11. That's about a third of where you began. You've kept publishing 8 to 9 things a week the whole time, so you're not posting less. Fewer people are reaching the freebie from what you post. Subscriber growth is slowing at the same rate (+18, +11, +8), and buyers usually follow a few weeks later. The freebie is where your whole business starts, so it's the number to fix.

**The one you may be avoiding:** money in and buyers have both slipped two weeks in a row. The drops are small, but they're heading the same way as the freebie numbers.

**One question:** did anything change about how people find the freebie about four weeks ago? For example, a link you moved, a pin that stopped getting views, or a new landing page.

**Is 2% good?** I don't have a reliable figure for other printable shops, so I won't guess one. Here's how you compare to yourself: buyers as a share of subscribers went from about 2.8% (6 of 212) in your first week to 2.0% (5 of 249) this week. You're not converting badly. The issue is that fewer new people are coming in at the top.

**Should you start TikTok?** My recommendation is not this month. You have 3 to 5 hours a week, and a new platform would use most of them before it changed any of your numbers. You'd also have less time for Pinterest and Instagram, which are already bringing people in. TikTok could eventually help your freebie downloads, but so could fixing the path you already have, and that's faster and costs nothing new. Look at it again once downloads are climbing. It's your call.

**What you're changing this week:** every post points to the freebie.

**Three priorities (about 3 hours, most important first)**
1. **Test the freebie path yourself (30 min).** Click through from your 3 most recent pins and your Instagram bio to the sign-up form, then the delivery email. Fix anything broken or slow.
2. **Write and schedule 5 new pins that go straight to the freebie (1.5 hrs).** The Pin Writer Bot can write these.
3. **Point your Instagram bio and 2 of this week's posts to the freebie (1 hr).** Change those 2 posts, not extra ones, so you're still at about 9 total.

The updated log is in MY_CEO_LOG.csv. Replace the old copy in your project knowledge with it as a backup. Keep this as one chat named "Monday CEO Review" and come back to it every week so I can see your history.

