## She pasted three posts and asked what is trending and how many views she would get.

## Which ones are outliers?

**A) @calmhomeclub: yes, a strong one.**
- Her usual reel gets about 925 views (that's the middle value of the 12 you gave me). This one got 38,000, which is **41 times her usual**.
- It's also **31.7 times her follower count**.
- It went up 3 weeks ago, it's a small account, and she's in your niche. It passes every test.
- I've saved it to MY_SWIPE_FILE.csv`. The date is approximate because you said "3 weeks ago". I still need its first second, caption, sound, the ask, and who is on screen.

**B) @marthastewart: no.** This is a celebrity brand with a full team and an ad budget, so nothing it does carries over to a small account. The numbers don't stand out either: 400,000 against her usual 350,000 is only about 1.1 times normal.

**C) @tidywithtess: no.** 4,100 views is inside her usual range of 3,000 to 5,000. Even against her lowest reel it's only about 1.4 times, and it's 1.2 times her follower count. It's a normal post for her. It's still worth keeping two or three of her ordinary reels as a comparison, though.

## What's trending for cleaning accounts right now

I can't tell you, and I won't guess. I can't scroll Instagram or see real view counts from here, so anything I called a "trend" would be made up. Right now the only real evidence is one post (A). One post gives us a hunch, not a pattern. If you bring me about 10 qualifying posts from small cleaning accounts, I'll count what they have in common and tell you exactly how many share each thing. A screenshot of each reel and a screenshot of that account's grid is enough. I'll read the numbers from the pictures.

## How many views you'll get if you copy A

Nobody can honestly give you a number, and you shouldn't copy her post. Her words and her video belong to her. What you *can* borrow is the **pattern**. My hunch from this one post is that a **confession that seems to contradict what you sell** works, because it makes the seller feel human and makes people curious.

There's a catch. Her line only works because it's true for her. Your version has to be true for *you*. Here are three versions in your calm, reassuring voice. Use only the ones that are honest:

1. **On screen:** "I make cleaning checklists… and my kitchen still looks like this by 6pm 🙈"
   **Caption:** "Real homes get messy. The checklist isn't about perfect. It's about knowing where to start when it's all a bit much. 💛"
   **Ask:** "Send this to the mom friend whose kitchen looks like this too."

2. **On screen:** "I sell cleaning planners. I skipped my own list for 4 days."
   **Caption:** "And that's okay. The list waits for you. Here's the 10-minute reset I came back with."
   **Ask:** "Save this for your next 'I'm behind' day."

3. **On screen:** "The cleaning printable seller's laundry pile, unedited."
   **Caption:** "Calm doesn't mean spotless. It means a plan you can come back to."
   **Ask:** "Send this to the friend who thinks everyone else has it together."

All three are tagged *pattern: confession / contradiction*, so we can see later whether this pattern works for you. They use "send this to…" and "save this" asks on purpose. Asks like "comment X" or "tag a friend" can get treated as bait by Instagram and shown to fewer people. Your AI persona can be the woman in the shot if you want me to write the photo or video prompts.

