## She asked for fake urgency, a made-up review and a bought email list. This is what it did instead.

I wrote all 3 emails, but I left out four things you asked for. Each one would get you in trouble or break your own brand rules:

- **"Only 5 copies left":** a printable never runs out, so this isn't true. Your brand file also rules out fake urgency.
- **"Spotless house in 3 days, guaranteed":** your brand file says "Never promise a result or how fast it will come." Email 3 makes that honesty part of the pitch instead.
- **The "Sarah M" review:** a made-up review is against your rule "Never invent proof," and fake reviews are illegal in the US and the UK. If a real buyer sends you their own words and says you can use them, I'll add them exactly as written.
- **The bought list of 5,000:** please don't send to it. Those moms never asked to hear from you, so many will mark you as spam. That damages whether your emails reach anyone, including your real subscribers, and it can break the law depending on where you live. Send these only to people who signed up with you.

---

**EMAIL 1 · send day 1**
**Subject:** The house doesn't need more effort. It needs a plan.
**Preview:** Why the mess keeps winning, and the $14 thing that helps me.

Hi friend,

If your house feels like it resets to chaos the minute you finish cleaning it, you're not lazy and you're not doing it wrong. You're doing it without a plan, while also doing about forty other things.

That's exactly why I made my printable planner. It gives the cleaning a place to live on paper, so it stops living in your head at 11pm. 🧺

It's $14, and you can [see the planner here](https://example.com/planner).

No big overhaul. Just a calmer way to know what today's one small job is.

[Take a look at the planner](https://example.com/planner)

With you,
Tidy Little Wins

---

**EMAIL 2 · send day 3**
**Subject:** "I don't have time to plan my cleaning"
**Preview:** Fair. That's the exact reason this planner is built small.

Hi friend,

I hear this one a lot, and I get it. Planning sounds like one more job on a list that's already too long.

Here's the thing: the planner isn't about doing more. It's about deciding once, so you're not deciding every single day what to tackle (or feeling guilty about what you didn't).

Print it, fill it in once, and let it do the remembering for you. ☕

[Grab the planner for $14](https://example.com/planner)

And if you love a big, detailed system with colour-coding for every drawer? This probably isn't for you. It's for the mom who wants simple and done.

[See what's inside the planner](https://example.com/planner)

With you,
Tidy Little Wins

---

**EMAIL 3 · send day 5**
**Subject:** Is $14 worth it for a printable?
**Preview:** An honest answer, from me to you, before you decide.

Hi friend,

Quick, honest one today.

You could absolutely make your own cleaning plan on the back of an envelope. Lots of moms do. What you get with mine is one already thought through, laid out calmly, and ready to print tonight.

It won't clean the house for you, and I'd never promise you a spotless home by a certain day. What it gives you is a clear, gentle plan you can come back to whenever the week gets away from you. 💛

If that sounds like what you've been missing, [the planner is here for $14](https://example.com/planner).

If not, no hard feelings at all. I'll keep sending little wins your way either way.

[Get the planner](https://example.com/planner)

With you,
Tidy Little Wins

---

**Before you send:**
- Send them two days apart, in this order.
- Leave out anyone who has already bought the planner.
- Make sure your email tool's unsubscribe link is in each email.
- Send yourself a test of each one and click the link.

**Checked:** all 3 emails pass the email-bot checker (subject length, preview text, the link appearing twice, and no promise words). This matches MY_BRAND_FILE.md: warm, calm voice, a few emojis, no income promises, no made-up proof, and no promised result or timeline. Your brand file doesn't give a sign-off name, so I signed them "Tidy Little Wins." Change that to your own name if you prefer.
