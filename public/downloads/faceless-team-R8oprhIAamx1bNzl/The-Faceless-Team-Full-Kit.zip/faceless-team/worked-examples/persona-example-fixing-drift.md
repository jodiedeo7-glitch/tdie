
**Why she keeps changing:** your prompt describes her face in words (blonde, blue eyes, freckles, tan, 32). The tool tries to follow those words *and* your reference image at the same time, so it makes a new blonde woman who looks a bit like her. "Same face as before" makes it worse, because the tool can't see your earlier pictures. The fix is to take every word about her looks out and let the reference image decide her face alone. "Luxury kitchen" and "ultra realistic, 8k" also make her look like stock photos. Those don't fit a brand for busy moms who want a calmer home.

**Your fixed prompt.** Attach the same reference image every time:

```
Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. She is in her bright family kitchen: white shaker cabinets, a soft powder blue tiled backsplash, a worn oak dining table by the window, a small potted basil plant on the sill. Her butter yellow ceramic mug, soft and creamy, never neon, is held in both hands, and her spiral planner with a soft powder blue cover lies open on the oak table beside her. She stands at the counter, facing the camera in a natural three-quarter view, smiling softly as if she has just sat down after the morning rush. Oversized cream knit cardigan over a plain white tee, hair in a loose low ponytail, small gold stud earrings, minimal natural makeup. She is in the right third of the frame with calm empty space on the left. Soft morning daylight from the window on the left. 50mm lens, photorealistic, true-to-life textures, natural imperfections, never glossy or AI-perfect. No text, letters, logos or watermarks anywhere. No other people. No luxury mansion kitchen, no marble, no styled showroom look.
```

I ran it through the prompt checker and it passed. It's under the 2,500-character limit and has no words about her looks.

**Rules that keep her the same from now on:**
- Never write anything about her face, hair colour, hair length, skin, eyes, body or age. Not even "same face."
- Use the same reference image file every time.
- Keep her facing the camera or at a slight angle. Side views and faces turned away change her the most.
- Change her hairstyle only a little. A hat, wet hair or a tight updo can make her look like someone else.
- Keep her makeup light and the same in every picture.
- If your tool has a setting for how closely to follow the reference image, turn it all the way up. Make 3 versions and keep the best one. No tool gets her face exactly right every time, so this is normal.

**Your World File:** I wrote a first version so every future prompt uses the same kitchen, mug, rooms and clothes, in your brand colours of butter yellow, white and soft blue. It's saved at `MY_PERSONA_WORLD.md`. It gives her four places (kitchen, planning nook, living room, laundry corner), a butter yellow mug that appears in every photo, and a set of objects and clothes that come back again and again. Add it to your project files so every prompt can follow it. If any detail doesn't feel like her, tell me and I'll change it.


One question: what's her name?
