## She pasted three comments (one was a refund complaint) and two quiet members.

**1) Dana**
> Oh, the 5-minute undo. I know it well 😅 What helps me is changing what counts as done. Don't measure the whole room. Pick one small spot, like the kitchen counter or the couch cushions, and call that today's win. It's still a win even if it only lasts until snack time. Which spot gets undone fastest at your place?

**2) Priya: you need to answer this one yourself**
I haven't written a full reply because this is a refund request and a broken download. Your brand file doesn't include a refund policy, so I've kept any promise about the money out of it. Here's an opening line you could use:
> Priya, I'm so sorry. You should have had your planner and an answer days ago, and I'm sending you a direct message right now to fix this.

Then sort out the link and the refund with her in a private message, not in the group.

**3) Kim**
> Yes! It has a one-room version made for smaller spaces, so you're not working through a checklist for rooms you don't have 💛 You can [grab the planner here](https://example.com/tidy). Which room do you find hardest to keep calm?

(This link is the main link from your brand file. If your group doesn't let you put a link behind words, paste the address underneath instead.)

**Quiet member check-ins**

**Lorraine**
> Hi Lorraine! I've been thinking of you. How's the paper clutter going? Is it mostly mail, kids' school papers, or something else piling up? 📬

**Bex**
> Hi Bex, just popping in to say hello 👋 What's one spot in your home you'd love to feel calmer about right now?

