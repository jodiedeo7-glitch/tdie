# Worked example (invented, for illustration only)

**What the user gave:**
- Product name: Calm Week Meal Planner
- Pages: weekly meal plan, grocery list, pantry inventory, favourite recipes page, monthly budget tracker
- Who it is for: busy mums feeding a family
- Format: printable PDF, A4 and US Letter

**Main phrase chosen:** meal planner printable

```
TITLE (104/140)
Meal Planner Printable, Weekly Family Meal Plan and Grocery List, Busy Mom Kitchen Organizer, A4 & Letter

TAGS (13)
1. meal planner (12)
2. printable planner (17)
3. weekly meal plan (16)
4. grocery list (12)
5. pantry inventory (16)
6. recipe page (11)
7. family menu planner (19)
8. busy mom organizer (18)
9. kitchen printable (17)
10. food budget tracker (19)
11. shopping list pdf (17)
12. dinner plan sheet (17)
13. a4 letter instant (17)

DESCRIPTION
For the busy mum who opens the fridge at 5pm with no plan. This meal planner puts the week's dinners, the shopping list and what's already in the cupboard on paper, so the evening question is answered before it starts.

WHAT'S INCLUDED
• Weekly meal plan
• Grocery list
• Pantry inventory
• Favourite recipes page
• Monthly budget tracker

WHAT YOU'LL RECEIVE
• This is a digital download. Nothing will be shipped to you.
• Printable PDF in A4 and US Letter sizes.

HOW IT WORKS
Download, print at home or at a print shop, and use it again every week.
```

Notice: the title opens with the chosen phrase; every tag is 20 or under; no word appears in more than two tags; every page listed is one the user named; the digital note is impossible to miss; no reviews, rankings or promised results.
