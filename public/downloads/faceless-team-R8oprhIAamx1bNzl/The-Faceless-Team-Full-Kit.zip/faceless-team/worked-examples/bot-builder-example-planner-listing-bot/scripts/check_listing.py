#!/usr/bin/env python3
"""Check an Etsy planner listing before showing it to the user.

Usage: python check_listing.py listing.json
listing.json holds: main_phrase, title, tags (list), description.
Prints PASS or a list of things to FIX. Exit code 0 = pass, 1 = fix.
"""
import json
import re
import sys
from collections import Counter

TITLE_MAX = 140      # Etsy's title limit
TAG_MAX = 20         # Etsy's tag limit
TAG_COUNT = 13       # Etsy allows 13 tags
WORD_REPEAT_MAX = 2  # no word in more than two tags
SMALL_WORDS = {"a", "an", "and", "for", "the", "of", "to", "with", "in", "on", "&"}
BANNED = [
    r"best[\s-]?sell", r"top[\s-]?rated", r"\b5[\s-]?stars?\b", r"five[\s-]?stars?",
    r"\breviews?\b", r"customers love", r"#\s?1\b", r"number one", r"guarantee",
]


def problems_in(listing):
    out = []
    phrase = (listing.get("main_phrase") or "").strip()
    title = (listing.get("title") or "").strip()
    tags = [t.strip() for t in listing.get("tags") or []]
    desc = listing.get("description") or ""

    # Title
    if not title:
        out.append("there is no title")
    else:
        if len(title) > TITLE_MAX:
            out.append(f"title is {len(title)} characters; Etsy's limit is {TITLE_MAX}")
        if not phrase:
            out.append("no main_phrase given, so the title start cannot be checked")
        elif not title.lower().startswith(phrase.lower()):
            out.append(f'title must start with the main phrase "{phrase}"')

    # Tags
    if len(tags) != TAG_COUNT:
        out.append(f"there are {len(tags)} tags; use exactly {TAG_COUNT}")
    for i, t in enumerate(tags, 1):
        if not t:
            out.append(f"tag {i} is empty")
        elif len(t) > TAG_MAX:
            out.append(f'tag {i} "{t}" is {len(t)} characters; the limit is {TAG_MAX}')
    lowered = [t.lower() for t in tags]
    dupes = [t for t, n in Counter(lowered).items() if n > 1]
    if dupes:
        out.append("these tags appear more than once: " + ", ".join(dupes))
    words = Counter()
    for t in lowered:
        for w in set(re.findall(r"[a-z0-9']+|&", t)):
            if w not in SMALL_WORDS:
                words[w] += 1
    for w, n in sorted(words.items()):
        if n > WORD_REPEAT_MAX:
            out.append(f'the word "{w}" is in {n} tags; keep it to {WORD_REPEAT_MAX} or fewer')

    # Description structure
    d = desc.lower()
    inc = d.find("what's included")
    if inc == -1:
        inc = d.find("what’s included")
    rec = d.find("what you'll receive")
    if rec == -1:
        rec = d.find("what you’ll receive")
    if inc == -1:
        out.append('description is missing the "WHAT\'S INCLUDED" section')
    if rec == -1:
        out.append('description is missing the "WHAT YOU\'LL RECEIVE" section')
    if inc != -1 and rec != -1 and rec < inc:
        out.append("WHAT'S INCLUDED must come before WHAT YOU'LL RECEIVE")
    if inc != -1 and len(desc[:inc].strip()) < 20:
        out.append("description must open with who the planner is for, before WHAT'S INCLUDED")
    if inc != -1:
        end = rec if rec > inc else len(desc)
        bullets = [l for l in desc[inc:end].splitlines() if l.strip().startswith(("•", "-"))]
        if not bullets:
            out.append("WHAT'S INCLUDED has no pages listed (one per line, starting with •)")
    if "digital download" not in d:
        out.append('description must say "digital download"')
    if not re.search(r"nothing (will be|is) (shipped|posted|mailed)|no physical", d):
        out.append('description must say nothing will be shipped (for example "Nothing will be shipped to you.")')

    # Banned claims anywhere
    everything = " ".join([title, " ".join(tags), desc]).lower()
    for pat in BANNED:
        m = re.search(pat, everything)
        if m:
            out.append(f'remove the claim "{m.group(0)}" (no reviews, rankings or guarantees)')
    return out


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 1
    with open(sys.argv[1], encoding="utf-8") as f:
        listing = json.load(f)
    problems = problems_in(listing)
    title = (listing.get("title") or "").strip()
    print(f"Title: {len(title)}/{TITLE_MAX}")
    for i, t in enumerate(listing.get("tags") or [], 1):
        print(f"Tag {i}: {t.strip()} ({len(t.strip())})")
    if problems:
        print("FIX:")
        for p in problems:
            print(f"  - {p}")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
