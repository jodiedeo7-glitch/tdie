## She asked for patterns from a 12-post swipe file, and to copy one post word for word.

## About copying post 1 word for word

I won't give you post 1's exact words to repost. They're that creator's words. Reposting them could also backfire on you. That exact sentence, "my house is never clean and I sell cleaning checklists", already appears on **7 of your 12 saved posts**, so your followers have probably seen it. What you can take is the *pattern* behind it, and Idea 1 below does that in your own words.

## What the swipe file shows (12 posts, all Instagram, all from October 2026)

All 12 count as real outliers: each got at least 5 times its account's normal views. I took the "normal" figures from your file. I couldn't recheck them because the file doesn't include each account's other posts.

**Patterns (5 or more posts behind them):**
1. **Confession hook: 7 of 12.** These did better than the rest. Their middle result was 31 times normal views, against 22 times for the others. → **Usable with a change:** the confession has to be true for you.
2. **Plain white text typed in the app, centred: 12 of 12.** → **Usable as it is.** It suits a faceless brand perfectly.
3. **"Send this to…" ask: 5 of 12.** → **Usable as it is.** It points at a kind of person ("send this to the friend who…"), which Instagram is less likely to treat as begging for engagement than "comment a word" or "tag 3 friends".
4. **A small numbered list of quick cleans ("5 things I clean in 10 minutes"): 5 of 12.** → **Usable with a change:** drop the minutes unless you've actually timed it, and never suggest the viewer will get a result fast.
5. **No face on screen: 10 of 12.** 5 had no person at all, 4 showed only hands and 1 was filmed from behind. → **Usable as it is.** Show your AI persona's hands, her back or her rooms rather than her face.

**Hunches (fewer than 5 posts, so weak evidence):**
- Showing a face: only 2 of 12, and one of those was the weakest post in the file (6 times normal).
- Asking for a save: 3 of 12.
- No ask at all: 3 of 12, but two of those hit 36 and 40 times normal.

**What's making these work:** a short, honest confession that pokes fun at the creator, typed as plain text over a scene with no face, then an ask that has the viewer send it to someone who'd relate. One caveat: your file has no ordinary posts from these accounts to compare against. So I can't tell whether the plain white text helped, or whether these accounts simply always post that way. Next time, also log 2–3 of each account's normal posts.

## Your 3 post ideas

**Idea 1: tests the confession hook + "send this to"**
- On screen: *I make cleaning checklists. There's a laundry pile on my sofa right now.*
- Caption first line: Real homes have laundry piles. Mine included 🧺
- Ask: Send this to the mum whose sofa looks like mine 💛
- Picture: your persona's hands folding one towel next to the pile, no face.
- ⚠️ Only post this if the laundry pile is true for you. If it isn't, swap in a mess you really have.

**Idea 2: tests the small numbered list + save**
- On screen: *3 little resets I do before bed so mornings feel calmer*
- Caption: 1. Clear the kitchen counter. 2. Shoes back by the door. 3. Tomorrow's list on the fridge. Small wins still count ✨
- Ask: Save this for tonight.
- Last caption line (the only line about your product): My printable evening reset checklist is here → https://example.com/tidy
- Picture: an empty room in butter yellow and soft blue, no person.

**Idea 3: tests no ask + no face (a hunch)**
- On screen: *Nobody's home looks like their Pinterest board. Not even the woman who sells the checklists.*
- Caption first line: Calm doesn't mean perfect. It means knowing where to start 🤍
- Ask: none.
- Picture: your persona from behind, holding a coffee mug, in a lived-in room.
- ⚠️ Only post this if it's true for you.

None of these promises views or results. The research improves your odds, nothing more. The Persona Bot can write the photo prompts for your AI persona whenever you want them.


One flag: this brand file is for **Tidy Little Wins**, not The Digital Income Edit™, so none of your TDIE rules or products went into these ideas.
