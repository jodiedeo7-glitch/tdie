## She asked for a week of 7 photo prompts. Her World File was already set up.
Here are 7 photo prompts for Maren, one for each day of the week. Each one works on its own: paste it into your image tool and attach your reference image every time. All four of her places are used, her yellow mug is in every photo, and the beagle, clipboard, blue throw and jar of pegs each appear more than once.

---

**PHOTO 1 · Monday · Dining table nook · ticking off her checklist**
Prompt: Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. She is in her dining table nook: a round pine table, a bench with a striped cushion, a window with white cafe curtains, a wall calendar with blank squares and no readable writing. Her butter yellow enamel mug with a white rim, saturated warm yellow, never pale, sits on the table by her hand. A clipboard with a printed checklist lies in front of her, its lines too small and soft to read. Her tan and white beagle, exactly one dog, rests under the bench at her feet. She sits on the bench ticking off a line on the checklist with a pencil, a small calm smile. Striped white and soft blue tee (clearly blue, never grey), denim overalls, hair in a loose low bun, short bare nails. She is in the right third of the frame with calm empty space on the left. Soft early-morning light through the white cafe curtains from the left. 35mm lens, photorealistic, true-to-life textures, natural imperfections, never glossy or AI-perfect. No text, letters, logos or watermarks anywhere. No other people. Not a luxury or mansion interior, not too perfect or plastic, not sexy.
Attach: your reference image
Caption idea: Monday, coffee, one small list. ☕ I don't try to do the whole house. I just pick the next little thing and tick it off. What's one thing on your list today?

---

**PHOTO 2 · Tuesday · Laundry room · folding towels**
Prompt: Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. She is in her laundry room: white shaker cabinets, a wicker basket, a row of glass jars on the shelf, a soft blue door (clearly blue, never grey). Her butter yellow enamel mug with a white rim, saturated warm yellow, never pale, stands on the cabinet top beside her. A glass jar of wooden clothes pegs sits next to the mug, and the wicker basket at her hip holds folded white towels. She is folding a white towel against her chest, mid-fold, relaxed. Oatmeal cardigan over a white tee, sleeves pushed up, hair in a high ponytail, small gold stud earrings, house slippers. She stands in the left third of the frame with calm empty space on the right. Soft mid-morning daylight coming through the half-open soft blue door. 35mm lens, photorealistic, true-to-life textures, slightly creased fabric, natural imperfections, never glossy or AI-perfect. No text, letters, logos or watermarks anywhere. No other people, no animals. Not a luxury or mansion interior, not too perfect or plastic, not sexy.
Attach: your reference image
Caption idea: One load, folded and put away before lunch. That's the whole goal today. 🧺 Small wins still count.

---

**PHOTO 3 · Wednesday · Front step · about to walk the dog**
Prompt: Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. She is on her front step: two terracotta pots of rosemary, a soft blue front door (clearly blue, never grey), a sisal doormat. Her butter yellow enamel mug with a white rim, saturated warm yellow, never pale, is held in both hands. Her tan and white beagle, exactly one dog, sits on the sisal doormat beside her, on a lead looped over her wrist, ready for a walk. She sits on the step, looking down at the dog with a soft laugh. Soft blue knit cardigan over a white tee, denim overalls, white sneakers with no logo, hair in two loose low braids. She sits in the right third of the frame, the blue door filling the background, open space on the left. Low warm late-afternoon sun from the side, gentle long shadows on the step. 50mm lens, photorealistic, true-to-life textures, natural imperfections, never glossy or AI-perfect. No text, letters, logos or watermarks anywhere. No other people, no house numbers. Not a mansion or luxury house, not too perfect or plastic, not sexy.
Attach: your reference image
Caption idea: Halfway through the week. Somebody here thinks it's walk time, and honestly, they're right. 🐾 The dishes can wait ten minutes.

---

**PHOTO 4 · Thursday · Living room · winding down at dusk**
Prompt: Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. She is in her living room: a cream slipcovered sofa, a soft blue knitted throw (clearly blue, never grey) over her knees, a low bookshelf behind her with plain unlabelled book spines. Her butter yellow enamel mug with a white rim, saturated warm yellow, never pale, is cupped in her hands. Her tan and white beagle, exactly one dog, is curled asleep against her on the sofa. She sits tucked into the corner of the sofa, legs folded under the throw, gazing toward the window, at ease. Oatmeal cardigan, white tee, hair loose and tucked behind one ear, house slippers on the floor below. She is centred slightly right, with soft empty wall on the left. Warm lamp light at dusk, gentle and low, a little blue evening light from the side. 50mm lens, photorealistic, true-to-life textures, natural imperfections, never glossy or AI-perfect. No text, letters, logos or watermarks anywhere. No other people. Not a luxury or mansion interior, not too perfect or plastic, not sexy.
Attach: your reference image
Caption idea: The kids are in bed, the lamp is on, and the list is done for today. The house doesn't have to be perfect to feel calm. 💛

---

**PHOTO 5 · Friday · Dining table nook · putting fresh printables on the clipboard**
Prompt: Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. She is in her dining table nook: a round pine table, a bench with a striped cushion, a window with white cafe curtains, a wall calendar with blank squares and no readable writing. Her butter yellow enamel mug with a white rim, saturated warm yellow, never pale, sits near the edge of the table. A neat stack of freshly printed pages, lines too small and soft to read, and a clipboard with a printed checklist lie on the pine table. She is clipping a fresh sheet onto the clipboard, focused and content, leaning slightly forward. Butter yellow cardigan, saturated and warm, never pale, over a white tee, hair in a claw clip, thin silver ring. She is in the left third of the frame with calm empty space on the right. Bright midday daylight through the white cafe curtains. 35mm lens, photorealistic, true-to-life textures, a few stray pencil marks and crumbs, never glossy or AI-perfect. No text, letters, logos or watermarks anywhere. No other people, no animals. Not a luxury interior, not too perfect or plastic, not sexy.
Attach: your reference image
Caption idea: Fresh checklist on the clipboard for next week. ✨ If a simple printed list would help your week feel calmer too, my checklists and planners are at the link in my bio.

---

**PHOTO 6 · Saturday · Laundry room · sorting the kids' washing**
Prompt: Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. She is in her laundry room: white shaker cabinets, a wicker basket, a row of glass jars on the shelf, a soft blue door (clearly blue, never grey). Her butter yellow enamel mug with a white rim, saturated warm yellow, never pale, rests on the cabinet top. A glass jar of wooden clothes pegs is in her hand, and her tan and white beagle, exactly one dog, sniffs at the wicker basket by her feet. She kneels by the basket, pulling out a small striped tee, smiling down at the dog. Striped white and butter yellow tee, denim overalls, white sneakers with no logo, hair in a messy top knot, a pencil tucked behind her ear. She is in the right third of the frame with calm empty space on the left. Soft Saturday-morning daylight through the half-open soft blue door. 35mm lens, photorealistic, true-to-life textures, natural imperfections, never glossy or AI-perfect. No text, letters, logos or watermarks anywhere. No other people. Not a luxury interior, not too perfect or plastic, not sexy.
Attach: your reference image
Caption idea: Saturday washing with my very nosy helper. 🐶 Two kids means lots of tiny socks, and a jar of pegs I somehow never have enough of.

---

**PHOTO 7 · Sunday · Living room · a quick reset**
Prompt: Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. She is in her living room: a cream slipcovered sofa, a soft blue knitted throw (clearly blue, never grey) folded over the sofa arm, a low bookshelf with plain unlabelled book spines. Her butter yellow enamel mug with a white rim, saturated warm yellow, never pale, sits on top of the low bookshelf. She holds a clipboard with a printed checklist, lines too small and soft to read, against her chest as she straightens a sofa cushion with her free hand, calm and unhurried. White tee, oatmeal cardigan, denim overalls, house slippers, hair in a low side braid. She is in the left third of the frame with calm empty space on the right. Soft Sunday-morning window light from the right, slightly hazy. 35mm lens, photorealistic, true-to-life textures, a gently lived-in room, natural imperfections, never glossy or AI-perfect. No text, letters, logos or watermarks anywhere. No other people, no animals. Not a luxury or mansion interior, not too perfect or plastic, not sexy.
Attach: your reference image
Caption idea: My Sunday reset takes about 15 minutes: cushions plumped, throw folded, and next week's list ready. 🌿 Not a deep clean, just a softer start to Monday.

---
