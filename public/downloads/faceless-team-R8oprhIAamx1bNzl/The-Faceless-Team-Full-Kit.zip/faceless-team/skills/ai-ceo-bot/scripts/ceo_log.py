#!/usr/bin/env python3
"""Keep and read the weekly five-number log.

Create:  python ceo_log.py init MY_CEO_LOG.csv "Name 1" "Name 2" "Name 3" "Name 4" "Name 5"
Add:     python ceo_log.py add MY_CEO_LOG.csv 2026-01-05 120 48 3 17 5
         (use the word "missing" for a number she does not have this week)
Report:  python ceo_log.py report MY_CEO_LOG.csv
"""
import csv
import sys


def read(path):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def fmt(x):
    return "missing" if x is None else (str(int(x)) if x == int(x) else f"{x:.2f}")


def report(path):
    head, rows = read(path)
    names = head[1:]
    if not rows:
        print("No weeks logged yet.")
        return
    last = rows[-1]
    prev = rows[-2] if len(rows) > 1 else None
    print(f"Week of {last[0]}  ({len(rows)} week(s) logged)")
    biggest = (None, 0.0)
    for i, name in enumerate(names, 1):
        now = num(last[i]) if i < len(last) else None
        before = num(prev[i]) if prev and i < len(prev) else None
        line = f"- {name}: {fmt(now)}"
        if now is not None and before is not None:
            change = now - before
            sign = "+" if change > 0 else ""
            pct = f" ({sign}{change / before * 100:.0f}%)" if before else ""
            line += f"  | last week {fmt(before)} | change {sign}{fmt(change)}{pct}"
            size = abs(change / before) if before else abs(change)
            if size > biggest[1]:
                biggest = (name, size)
        elif prev:
            line += "  | no comparison (a number is missing)"
        # streaks: down two weeks running, or flat for four
        vals = [num(r[i]) if i < len(r) else None for r in rows]
        if len(vals) >= 3 and None not in vals[-3:] and vals[-1] < vals[-2] < vals[-3]:
            line += "  | DOWN two weeks running"
        if len(vals) >= 4 and None not in vals[-4:] and len(set(vals[-4:])) == 1:
            line += "  | has not moved in four weeks"
        print(line)
    if biggest[0]:
        print(f"Biggest mover: {biggest[0]}")
    if not prev:
        print("First week logged. Changes appear from next week.")


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    cmd, path = sys.argv[1], sys.argv[2]
    if cmd == "init":
        names = sys.argv[3:]
        if len(names) != 5:
            print("Give exactly five number names.")
            return 1
        with open(path, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(["week"] + names)
        print("Log created.")
    elif cmd == "add":
        vals = sys.argv[3:]
        if len(vals) != 6:
            print("Give the date and exactly five numbers.")
            return 1
        with open(path, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(vals)
        print("Week saved.")
    elif cmd == "report":
        report(path)
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
