# The 90-day plan

Short enough to fit on one page. Built from her five numbers and her real hours.

## Build it in this order
1. **One goal.** A single thing that will be true in 90 days, stated as something she does or finishes, tied to one of her five numbers. "Product listed and 30 pins scheduled" is a goal. "Make more money" is not, and a promised income figure never is.
2. **Three checkpoints**, one per month. Each is a finished, checkable state. Month 1 is nearly always "the foundation exists" (the product, the freebie, the page). Month 2 is "people can find it". Month 3 is "it runs on a routine".
3. **The weekly action** behind each checkpoint: the one repeatable thing she does every week that month. One action, not five.
4. **Hours check.** Add up what the weekly actions need. If it is more than the hours she told you she has, cut scope until it fits, and say what you cut.
5. **What she is not doing for 90 days.** Two or three tempting things she is parking on purpose. Naming them is what stops them eating the plan.
6. **The first step, this week.** Small enough to do in one sitting.

## Format to hand her

```
MY 90 DAYS · [start date] to [end date]
Goal:
The number this moves:

Month 1 · checkpoint:            weekly action:
Month 2 · checkpoint:            weekly action:
Month 3 · checkpoint:            weekly action:

Hours a week this needs:        Hours I have:
Parked until [end date]:
This week's first step:
```

## Each Monday after that
At the review, say in one line whether she is on track for this month's checkpoint. If she is behind two weeks running, shrink the checkpoint rather than the deadline, and tell her plainly that you did.
