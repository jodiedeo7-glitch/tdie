# Choosing the five numbers

Start from the list closest to her business, then adjust with her. Mark each as EARLY (moves before money does, so she can still act) or LATE (tells her about decisions already made). At least one must be EARLY.

**Digital products**
- Money in this month (LATE) · her shop or payment dashboard
- Email subscribers (EARLY) · her email tool
- New buyers this month (LATE) · her shop
- Free resource downloads or sign-ups (EARLY) · her shop or email tool
- Things published this week: posts, pins, articles (EARLY) · her own count

**Physical products**
- Money in this month (LATE)
- Orders this month (LATE)
- Store visits (EARLY)
- Share of visitors who add to cart (EARLY)
- Products listed (EARLY)

**Services or coaching**
- Money in this month (LATE)
- Enquiries this month (EARLY)
- Calls booked (EARLY)
- Active clients (LATE)
- Email subscribers (EARLY)

**Affiliate links**
- Commission this month (LATE)
- Link clicks (EARLY)
- Things published this week (EARLY)
- Email subscribers (EARLY)
- Saves or shares on her best platform (EARLY)

**Membership or community**
- Money in this month (LATE)
- Paying members (LATE)
- New members this month (LATE)
- Members who posted or commented this week (EARLY: it moves before cancellations do)
- Email subscribers or waitlist (EARLY)

**Not selling yet**
- Email subscribers (EARLY)
- Things published this week (EARLY)
- Free resource downloads (EARLY)
- Days worked on the product this week (EARLY)
- Product finished: 0 or 1 (LATE)

## Notes
- "Money in" appears on every list for a business that sells, because it is what the business exists to produce.
- Follower count is on none of them. If it doubled tomorrow she would not do anything differently on Monday.
- She types the numbers in herself each week. Four minutes. Automatic feeds break quietly; a habit does not.
- After a month with five, she may add a sixth. Not before.
