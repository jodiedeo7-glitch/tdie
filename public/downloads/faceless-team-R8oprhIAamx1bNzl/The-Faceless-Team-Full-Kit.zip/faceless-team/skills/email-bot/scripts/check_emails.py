#!/usr/bin/env python3
"""Check a set of emails.

Usage: python check_emails.py emails.txt

emails.txt holds one email per block; blocks are separated by a line containing only ===
Each block starts with these two lines, then a blank line, then the body:
  SUBJECT: ...
  PREVIEW: ...
Links in the body are written as [the words](https://the-link)
Put the word WELCOME1 on its own first line of a block that is the freebie delivery email
(it is allowed to have its link once).
Exit code 0 = all pass. 1 = at least one problem.
"""
import re
import sys

LINK = re.compile(r"\[([^\]]+)\]\((https?://[^)\s]+)\)")
BARE = re.compile(r"(?<!\()https?://\S+")
RISKY = [
    r"\bguarantee[ds]?\b", r"\brisk[- ]free\b", r"\bget rich\b", r"\bpassive income overnight\b",
    r"\bin just \d+ (days?|weeks?|hours?)\b", r"\bmake \$\d", r"\bearn \$\d", r"\b\d+k (a|per) month\b",
    r"\bonly \d+ (spots?|seats?|copies) left\b", r"\bact now\b", r"\bdon'?t miss out\b",
]


def check(block):
    problems = []
    text = block.strip()
    welcome1 = False
    if text.startswith("WELCOME1"):
        welcome1 = True
        text = text[len("WELCOME1"):].lstrip()
    subj = re.search(r"^SUBJECT:\s*(.*)$", text, re.MULTILINE)
    prev = re.search(r"^PREVIEW:\s*(.*)$", text, re.MULTILINE)
    if not subj or not subj.group(1).strip():
        problems.append("no subject line")
    else:
        s = subj.group(1).strip()
        if len(s) > 60:
            problems.append(f"subject is {len(s)} characters (keep it under about 50, never over 60)")
        if s.isupper() or "!!" in s:
            problems.append("subject is shouting")
    if not prev or not prev.group(1).strip():
        problems.append("no preview text")
    else:
        p = prev.group(1).strip()
        if not 30 <= len(p) <= 110:
            problems.append(f"preview text is {len(p)} characters (aim for 40 to 100)")
        if subj and p.lower() == subj.group(1).strip().lower():
            problems.append("preview text repeats the subject")
    body = re.sub(r"^(SUBJECT|PREVIEW):.*$", "", text, flags=re.MULTILINE)
    links = LINK.findall(body)
    targets = {u.rstrip("/") for _, u in links}
    if len(targets) > 1:
        problems.append(f"{len(targets)} different link targets (one ask per email)")
    need = 1 if welcome1 else 2
    if len(links) < need:
        problems.append(f"the ask link appears {len(links)} time(s) (needs {need})")
    stripped = LINK.sub("", body)
    if BARE.search(stripped):
        problems.append("a bare web address is pasted in (put the link behind words)")
    for pattern in RISKY:
        m = re.search(pattern, body, re.IGNORECASE)
        if m:
            problems.append(f'check this phrase is true and hers to say: "{m.group(0)}"')
    return problems


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 1
    with open(sys.argv[1], encoding="utf-8") as f:
        blocks = [b for b in re.split(r"^\s*===\s*$", f.read(), flags=re.MULTILINE) if b.strip()]
    failed = False
    for i, block in enumerate(blocks, 1):
        problems = check(block)
        if problems:
            failed = True
            print(f"EMAIL {i}: FIX")
            for p in problems:
                print(f"  - {p}")
        else:
            print(f"EMAIL {i}: pass")
    print("\nAll emails pass." if not failed else "\nFix the emails marked FIX and run again.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
