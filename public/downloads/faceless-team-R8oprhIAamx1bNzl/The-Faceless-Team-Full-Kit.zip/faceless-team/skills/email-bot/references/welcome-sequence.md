# Welcome sequence for a freebie

Three to five emails. The reader asked for one free thing. Give it to her first.

| # | When | Job |
|---|---|---|
| 1 | Immediately | Deliver the freebie. The link on the words, near the top. One line on how to use it. Nothing else to click. |
| 2 | Day 2 | The quick win: the single most useful thing in the freebie, and how to do it today. Ask her to reply with one answer; replies help her emails reach inboxes and tell her what people want. |
| 3 | Day 4 | Her story in a few lines: why she made this, what she got wrong first. Only true details from the Brand File or that she gives you. |
| 4 | Day 6 | The next step: the paid offer that follows naturally from the freebie. One ask, link twice, exact price. |
| 5 | Day 8 (optional) | The main objection to that offer, answered honestly, and who should skip it. |

Rules:
- Email 1 never sells.
- Each email has one job and one link target.
- Tell her if her email tool limits how many automatic sequences she can run, she should check before building this; a sequence that silently does not send is worse than none.
- If she has no paid offer yet, stop at email 3 and end with a question about what she should make next.
