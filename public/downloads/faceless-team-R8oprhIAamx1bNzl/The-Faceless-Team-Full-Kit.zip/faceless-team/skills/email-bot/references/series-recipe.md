# The six-email sales series

## The shape of the series

| # | Day | Job |
|---|---|---|
| 1 | Day 1 | The biggest objection. No hard sell: send her to look inside, if a look-inside exists. |
| 2 | Day 3 | The second objection. First clear ask to buy. |
| 3 | Day 5 | The money email. The price and any payment plan, explained completely. |
| 4 | Day 7 | The trust email. Refund policy stated plainly, the look-inside, a real buyer's words if she has them. |
| 5 | Day 9 | The "not ready / not for me" email. Says who it is for and who should skip it. |
| 6 | Day 10 or deadline day | The "later" email. Built around the real deadline if there is one. |

If there is a deadline, count back from it so email 6 lands on the last day and email 5 the day before.

## The shape of each email

**Subject line.** Under about 50 characters. About the objection or a specific, slightly surprising fact. Reads like a note from a person. No all-caps, no "!!!", no "last chance" unless it is.

**Preview text.** One line, 40 to 100 characters, that adds something the subject did not say. Never repeats the subject.

**Opening.** Speak to the woman who has this objection: "If [the situation], this one's for you." Then say the objection out loud, in her words. Agree with what is true about it.

**The turn.** The one thing she has not understood about the offer that changes the objection. Concrete. Short paragraphs.

**The ask, first time.** One line, link on the words. Place it after the turn, about a third of the way down.

**The proof or detail.** What her part is, the real numbers, the honest fine print.

**The ask, second time.** Same link, different words, near the end.

**Sign-off.** From her Brand File. If none is set, her first name.

**P.S.** One job only: the deadline or bonus if there is one, or what the next email is about.

## Rules for the whole series
- One link target per email, used twice.
- Exact prices every time. Full product name on first mention in each email.
- The series never mentions that the reader "hasn't bought yet" or that she was on a waitlist. It speaks to the objection, not to her behaviour.
- No email depends on the reader having read the previous one.
- Plain text feel. No images required. Bold only for the one thing she must not miss.
- Read each email aloud in her voice. If a line sounds like an advert, rewrite it as something she would say to a friend.
