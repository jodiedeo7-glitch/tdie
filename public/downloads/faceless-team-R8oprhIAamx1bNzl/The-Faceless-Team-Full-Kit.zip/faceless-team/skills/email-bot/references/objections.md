# Why people have not bought

Offer these as a tick list. Use the ones she ticks, in the order she thinks is most common, and fill to six from the rest.

1. **"I can't do this."** She thinks it needs a skill she does not have (tech, design, writing, being on camera).
2. **"I don't have time."** She thinks it needs a block of time her life does not contain.
3. **"It's a lot of money right now."** Price, or price this month.
4. **"What if it isn't what I think it is?"** Fear of being stuck with the wrong thing. This is where the refund policy and any look-inside belong.
5. **"I'm not ready / I don't have enough yet."** She thinks she needs an audience, more content, a title or more experience first.
6. **"I'll do it later."** No reason to act now.
7. **"I've bought things like this before and they didn't work."**
8. **"Is this for someone like me?"** She cannot see herself in it.
9. **"I can figure this out myself for free."**
10. **"I don't know what I'd actually get."** The offer is unclear.

## Answering each honestly

- **Can't do this:** show exactly what her part is, in small steps, and what the product does for her. Say what happens when something goes wrong.
- **No time:** break the real time needed into pieces and show it can be spread out. Never shrink the true number.
- **Money:** explain any payment plan fully, including any extra it costs. Compare to the realistic alternative she would otherwise pay for, using only figures the owner can stand behind. If she cannot afford it, do not push; say it will still be there.
- **Not what I think:** state the refund policy plainly. Point to whatever lets her look first. A real buyer's own words belong here.
- **Not ready:** say what she truly needs to start, and say honestly who should wait.
- **Later:** what waiting costs her in plain, non-dramatic terms. A real deadline if there is one.
- **Burned before:** say what is different in concrete terms, not adjectives.
- **Someone like me:** describe the buyer specifically. Name who it is not for.
- **Free elsewhere:** agree that she could, then say what the product saves her (time, order, the mistakes already made).
- **Unclear:** say in one sentence what she will have at the end, then list what is inside.
