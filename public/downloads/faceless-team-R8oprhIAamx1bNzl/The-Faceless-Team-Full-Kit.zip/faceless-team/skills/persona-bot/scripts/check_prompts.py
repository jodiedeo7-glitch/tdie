#!/usr/bin/env python3
"""Check persona photo prompts.

Usage: python check_prompts.py prompts.txt
prompts.txt holds one prompt per block; blocks are separated by a line containing only ---
A block that starts with NO PERSON is checked as a photo without her in it.
Exit code 0 = all pass. 1 = at least one problem.
"""
import re
import sys

MAX_CHARS = 2500
OPENING = ("Photograph of this exact woman from the attached reference image. "
           "Identity is taken only from the reference.")
HEX = re.compile(r"#[0-9A-Fa-f]{6}\b|#[0-9A-Fa-f]{3}\b")
LOCKED = [
    r"\b(blonde|brunette|redhead|red[- ]haired|dark[- ]haired|fair[- ]haired|raven[- ]haired)\b",
    r"\b(blue|green|brown|hazel|grey|gray|amber|dark)[- ]eye[ds]?\b",
    r"\beye colou?r\b", r"\bhair colou?r\b", r"\b(long|short|shoulder[- ]length|waist[- ]length) hair\b",
    r"\b(brown|black|blonde|red|auburn|silver|grey|gray|pink|dark|light|golden|chestnut) hair\b",
    r"\bfreckle[sd]?\b", r"\bskin tone\b", r"\b(pale|tan|tanned|olive|fair|dark|light|porcelain)[- ]skin(ned)?\b",
    r"\b(slim|slender|curvy|petite|athletic|plus[- ]size) (build|figure|body|woman)\b",
    r"\b\d\d[- ]year[- ]old\b", r"\bin her (twenties|thirties|forties|fifties|20s|30s|40s|50s)\b",
    r"\bsame (face|eyes|hair|freckles|skin)\b", r"\bfacial (structure|features)\b",
]


def check(block):
    problems = []
    text = block.strip()
    no_person = text.upper().startswith("NO PERSON")
    if no_person:
        text = text[len("NO PERSON"):].lstrip(" :\n")
    if len(text) > MAX_CHARS:
        problems.append(f"{len(text)} characters (limit {MAX_CHARS})")
    if not no_person and not text.startswith(OPENING):
        problems.append("does not open with the identity line, word for word")
    if HEX.search(text):
        problems.append("contains a colour code (write the colour as a name plus a shade)")
    for pattern in LOCKED:
        m = re.search(pattern, text, re.IGNORECASE)
        if m and not no_person:
            problems.append(f'describes a locked feature: "{m.group(0)}"')
    low = text.lower()
    if "no text" not in low and "no lettering" not in low:
        problems.append('missing the "no text, letters, logos or watermarks" line')
    return problems


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 1
    with open(sys.argv[1], encoding="utf-8") as f:
        blocks = [b for b in re.split(r"^\s*---\s*$", f.read(), flags=re.MULTILINE) if b.strip()]
    failed = False
    for i, block in enumerate(blocks, 1):
        problems = check(block)
        if problems:
            failed = True
            print(f"PROMPT {i}: FIX")
            for p in problems:
                print(f"  - {p}")
        else:
            print(f"PROMPT {i}: pass")
    print("\nAll prompts pass." if not failed else "\nFix the prompts marked FIX and run again.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
