# When she keeps looking different

Adding more description of her face makes it worse, because words about her features compete with the reference image. Work through these in order and change one thing at a time.

1. **Check the prompt for feature words.** Remove anything about her face, eyes, skin, hair colour, hair length, body or age, including "same" and "unchanged". Run the checker script if you can.
2. **Check the reference image was attached**, and that it is the same file every time.
3. **Simplify the scene.** Fewer props, fewer accessories. Busy prompts pull attention away from the reference.
4. **Use a natural front or three-quarter view.** Extreme angles, profile shots and faces turned away drift most.
5. **Leave her hair mostly alone.** A dramatic style change (a tight updo, a hat, wet hair) can read as a different person. Change it gently.
6. **Keep makeup minimal and the same.** A changed face reads as a changed woman.
7. **Check the light.** Harsh, coloured or very dark light changes how her face reads. Use soft daylight or a warm lamp.
8. **Try the tool's strongest reference setting**, if it has one, and generate a few to choose from.
9. **Still drifting?** The reference image may be the weak point (small face, heavy makeup, odd angle). Make a clearer one using the reference-image guide.

Tell her honestly: no tool holds a face perfectly every time. The aim is that a follower scrolling her feed never doubts it is the same woman. Generating three and keeping the best is normal.
