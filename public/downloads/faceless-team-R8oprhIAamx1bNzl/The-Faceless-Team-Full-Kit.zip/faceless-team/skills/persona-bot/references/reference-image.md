# Making her reference image

The reference image is the single source of who she is. It is made once. After that, she is never described in words again.

## The one time her features are described
Creating the reference is the only moment a description of her face, hair, skin, build and age is written. Ask the owner (pick-a-number where you can) for: approximate age, hair colour and length, eye colour, skin tone, build, and one or two distinguishing details such as freckles. Keep it to what the owner chooses. Do not base her on a real person or a celebrity.

## What a good reference looks like
- One woman, plain light background, even soft daylight, no heavy makeup, simple plain top.
- Face clearly visible and unobstructed: a straight-on view is essential. If the tool allows several views on one sheet (front, three-quarter, side, a full-length), ask for a sheet; it holds identity better than a single photo.
- No props, no text, no dramatic lighting, no sunglasses or hats.

## Prompt to hand her (fill the brackets from her answers)
> Character reference sheet of one woman on a plain light background, even soft daylight. Four views of the same woman: front-facing head and shoulders, three-quarter view, side profile, and full length standing. [Age range]. [Hair colour, length and how it falls]. [Eye colour]. [Skin tone]. [Build]. [One or two distinguishing details]. Natural minimal makeup, plain white top. Photorealistic, true-to-life skin texture, never glossy or AI-perfect. No text, labels, logos or watermarks.

## After she makes it
1. Tell her to generate a few and choose the one she would be happy to see every day for a year.
2. Save it somewhere safe with a clear name. This file is her persona.
3. Attach it to every prompt from now on. Add "Reference image: yes" to her World File.
4. From this point, no prompt describes her features. If she wants to change her look, she makes a new reference image; she does not edit her with words.
