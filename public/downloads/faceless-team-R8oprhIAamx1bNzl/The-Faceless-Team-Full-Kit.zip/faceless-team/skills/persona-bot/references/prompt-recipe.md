# Photo prompt recipe

Write each prompt in this order. Earlier parts are obeyed more reliably than later parts, so the things that must not go missing come first.

1. **Identity.** The opening line, word for word (only when she is in the frame).
2. **Place.** One place from the World File, with its fixed details named exactly as the file names them.
3. **Signature prop and two or three named objects**, placed in the scene ("on the counter beside her", "at her feet").
4. **Action.** One believable thing she is doing.
5. **Outfit and hair.** From her wardrobe; hair worn a particular way; one small changeable detail (nails, a necklace).
6. **Composition.** Where she is in the frame and where the empty space is, if words will be added later ("she is in the right third; calm empty space on the left").
7. **Light.** A real source: soft morning window light, golden-hour sun through the porch rail, a warm lamp at night.
8. **Camera and realism.** A lens (35mm, 50mm or 85mm) and plain realism words: photorealistic, true-to-life textures, natural imperfections, never glossy or AI-perfect.
9. **Negative line.** No text, letters, logos or watermarks anywhere. No other people. Plus anything on her "never" list.

## Scene density
Two to five things anchoring the place, one action, one outfit, the signature prop, one or two signs of real life. Every detail must earn its place. If it does not help identity, world, story or realism, cut it.

## If a prompt is over 2,500 characters
Cut in this order: repeated wording, then small decorative details, then long realism sentences (keep "photorealistic, true-to-life textures, never glossy or AI-perfect"). Never cut the identity line, the signature prop, the named place details, animal counts, the composition line or the negative line.

## If a picture comes back looking generic
Do not add "more luxurious" or "more beautiful". Ask instead: is the place really one of hers? Are its fixed details in the first half of the prompt? Is she doing something believable? Is the light a real light?

## If a picture comes back looking fake
Do not repeat "ultra realistic". Fix the scene: simpler composition, one statement detail instead of five, a real light source, natural hand position, fabric that wrinkles.

## Worked example (invented persona, for shape only)

> Photograph of this exact woman from the attached reference image. Identity is taken only from the reference. She is in her small apartment kitchen: open oak shelves, a white tiled wall, a blue enamel kettle on the stove. Her chipped mustard yellow mug, saturated and warm, never pale, is in her hand, and her grey tabby cat sits on the windowsill, exactly one cat. She leans on the counter reading a paper notebook. Oversized oatmeal cardigan over a white tee, hair in a loose low bun, small gold hoop earrings. She is in the right third of the frame with calm empty space on the left. Soft morning window light from the left. 50mm lens, photorealistic, true-to-life textures, natural imperfections, never glossy or AI-perfect. No text, letters, logos or watermarks anywhere. No other people.
