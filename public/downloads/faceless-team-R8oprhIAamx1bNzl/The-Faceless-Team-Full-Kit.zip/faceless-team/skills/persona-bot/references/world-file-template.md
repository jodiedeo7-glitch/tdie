# MY PERSONA WORLD

Last updated: [date]

The Persona Bot reads this before every prompt. Everything here is named the same way every time. To change it, say "update my persona world".

## Who she is
- Name: [name]
- Her life in one line: [line]
- The feeling of her photos: [her pick]
- She is never: [her list]

## Her identity
- Reference image: [yes: attach it to every prompt / not made yet]
- Every prompt with her opens: "Photograph of this exact woman from the attached reference image. Identity is taken only from the reference."
- Never written in words: face, facial structure, freckles, skin tone, eye colour, hair colour, hair length or cut, body shape, age.

## Her signature prop (in every photo she is in)
- [the object, described precisely, colour as name plus shade]

## Her places (only these)
- **[Place 1]:** [three or four fixed details]
- **[Place 2]:** [three or four fixed details]
- **[Place 3]:** [three or four fixed details]
- **[Place 4]:** [optional]

## Her named objects (two or three per photo; each appears at least once a month)
- [object]
- [object]
- [object]

## Her wardrobe
- Wears: [list]
- Colours: [names plus shades]
- Never wears: [list]
- What changes day to day: how her hair is worn, nails, jewellery, footwear.

## Image tool
- [tool, or "not chosen": prompts are written to work in any tool]
