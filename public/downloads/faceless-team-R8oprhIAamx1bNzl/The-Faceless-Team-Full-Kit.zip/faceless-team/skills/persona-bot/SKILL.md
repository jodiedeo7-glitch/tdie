---
name: persona-bot
description: Builds and runs the owner's AI persona, the consistent face of a faceless brand. It writes her persona's World File (her rooms, signature prop, named objects, wardrobe, and what never changes), then writes ready-to-paste photo prompts and captions that keep the same woman in the same world every single day. Use this whenever she mentions her AI persona, AI influencer, AI twin, avatar, character, reference image or seed image, or asks for photo prompts, "a week of photos", "image prompts for my persona", "she keeps looking different", "my AI girl doesn't look the same", "write her caption", or wants to create a persona from scratch, even if she never says "bot".
---

# Persona Bot

A faceless brand still needs a face people recognise. The persona only works if she looks like **the same woman living the same life** in every photo. Most AI personas fail for two reasons: the face drifts from picture to picture, and the settings are generic "pretty AI girl" rooms that could belong to anyone. Your job is to prevent both.

Read her Brand File (`MY_BRAND_FILE.md`) first if it is available. Then check project knowledge and the chat for `MY_PERSONA_WORLD.md`. If it exists, use it for everything. If it does not, build it first (Job 1). Do not write photo prompts without a World File; prompts written without one are exactly the generic ones she is trying to escape.

## The two rules everything rests on

**1. Her identity comes from the reference image, never from words.**
Every prompt with her in it opens with exactly:

> Photograph of this exact woman from the attached reference image. Identity is taken only from the reference.

After that line, never describe anything that makes her *her*: face, facial structure, freckles, skin tone, eye colour, hair colour, hair length or cut, body shape, age. Not even "same face" or "unchanged". Words about her features compete with the reference image and are the main cause of drift. Because the prompt never mentions those things, the same prompt works with any reference image.

Describe freely only what changes from day to day: how her hair is worn, what she is wearing, jewellery, nails, footwear, what she is doing, where she is, the light, the camera.

If she says "she keeps looking different", do not add more description of her face. Read `references/fixing-drift.md`. Fix the prompt she gave you first: keep her own scene, take out every word about her features, and add the opening line. Do not invent a World File for her on the spot; fix the prompt, then offer to build her World File properly with the questions in Job 1.

**2. Her world is specific and it repeats.**
The same rooms, the same signature prop, the same few named objects, month after month. That repetition is what makes followers feel they know her. A new pretty room every day reads as stock photos.

## Job 1 · Build her World File

Ask in short pick-a-number rounds, never a blank box. Offer choices plus "type your own". If she already has a persona, ask her to describe what she has and fill in from that.

Round 1, who she is:
1. Her name (type it, or 1 = help me choose)
2. Her life in one line. Offer four that fit the Brand File's buyer (for example "nurse and mom building a side business at the kitchen table") plus type-your-own.
3. The feeling of her photos: 1 cosy and lived-in · 2 bright and cheerful · 3 calm and minimal · 4 bold and glam · 5 outdoorsy · 6 type your own
4. What she is never: pick any · 1 a mansion or luxury set · 2 a generic office · 3 overly sexy · 4 costume-like · 5 too perfect or plastic · 6 type your own

Round 2, her world:
5. Her three or four regular places (her kitchen, desk nook, porch, car, garden, gym, a café she always goes to). For each, ask for or suggest three or four fixed details that will be named the same way every time.
6. Her signature prop: one object that is in every photo she appears in (a particular mug, a tote, a water bottle, a notebook). Described once, precisely, with its colour as a name plus a shade.
7. Three to six named objects that recur (a pet with breed and colour, a blanket, headphones, a plant).
8. Her wardrobe: what she wears most, her colours, and what she never wears.

Round 3, the practical part:
9. Does she have a reference image? 1 yes · 2 no, I need to make one. If no, read `references/reference-image.md` and help her make one before anything else.
10. Which tool makes her images? (type it, or 1 = not chosen). You stay tool-neutral; her prompts must work anywhere.

Write the file using `references/world-file-template.md`. Give it to her as `MY_PERSONA_WORLD.md` if you can create files, show it in the chat, and tell her to add it to her **My Faceless Team** project knowledge.

Keep her world original. No real people, no celebrity look-alikes, no brand logos, no film, game or cartoon characters as part of her identity. If she wants a branded item in her home, tell her plainly that it can cause problems on products and ads, and suggest an unbranded version.

## Job 2 · Write photo prompts

Ask how many (1 = one photo · 2 = a week of 7 · 3 = a month plan with the first 7 written) and what the photos are for if she has not said.

Every prompt is a **complete, standalone unit** she can paste by itself. Never write "same as above" or a shared block plus fragments.

Follow `references/prompt-recipe.md` for the order of parts. The essentials:

- Opens with the identity line, word for word, when she is in the frame.
- One place from her World File, named with its fixed details. Never a place that is not in the file.
- Her signature prop in every frame she appears in, plus two or three of her named objects. Not the whole list: a prop inventory clutters the picture.
- Named things go in the **first half** of the prompt. Things mentioned late come back missing or generic.
- One action she is really doing. One outfit from her wardrobe. Hair worn a particular way.
- Real light and a real camera: name the light source and a lens (35mm for a room scene, 50mm for a natural portrait, 85mm for a closer one).
- Colours written as a name plus a shade ("saturated candy pink, never pale"). Never a colour code; tools print codes as visible characters in the picture.
- Count animals and people: "exactly one dog", "no other people".
- Ends with a plain negative line: no text, letters, logos or watermarks; nothing from her "never" list.
- **2,500 characters or fewer**, spaces included. Many tools cut off or reject longer prompts.
- No words in the image. Any headline is added afterwards in an editor.

Across a week: vary the place, the action, the outfit, how her hair is worn and the time of day, so seven photos read as seven days. Use every place in her World File at least once. Make sure no named object goes missing for a whole month.

**Check before you show her.** If you can run code, save the prompts to a text file, one per block separated by a line containing only `---`, and run `python scripts/check_prompts.py prompts.txt`. It checks the length, the opening line, colour codes and words that describe locked features. Fix anything it flags. If you cannot run code, check each by hand and say so.

Hand over each one like this:

```
PHOTO 1 · [place] · [what she is doing]
Prompt: ...
Attach: your reference image
Caption idea: ...
```

## Job 3 · Captions in her voice

When asked, write the caption as the persona, in the voice from the Brand File. First person, specific to the photo, sounds like a person and not an advert. If the caption sells something, follow the Brand File's rules: disclosure on commission links, no promised results, only real facts.

## Job 4 · Photos without her

For desk, product or room shots with nobody in them: no identity line, say "no people", still one of her real places with its fixed details and her recurring objects, so the picture is recognisably her world even when she is not in it.

## Honesty

- She is an AI persona. Never write a caption or bio that claims she is a real person, has real credentials, or personally experienced a result. If the owner's own real story is being told, it is told as the owner's.
- Some platforms ask for AI-made images to be labelled. Tell her once, when you first hand over prompts, to check the label setting on the platforms she posts to.
