#!/usr/bin/env python3
"""Check a batch of pins against the Pin Writer Bot limits.

Usage: python check_pins.py pins.json
pins.json is a list of objects with: overlay, title, description, alt
Exit code 0 = every pin passes. 1 = at least one problem.
"""
import json
import re
import sys

LIMITS = {"title": (60, 100), "description": (450, 500), "alt": (150, 200)}
OVERLAY_WORDS = (3, 5)
SPAM_PHRASES = ["make money online"]
PRICE = re.compile(r"[$£€]\s?\d")


def check(pin, n):
    problems = []
    words = len(str(pin.get("overlay", "")).split())
    if not OVERLAY_WORDS[0] <= words <= OVERLAY_WORDS[1]:
        problems.append(f"words on image: {words} words (needs {OVERLAY_WORDS[0]} to {OVERLAY_WORDS[1]})")
    for field, (lo, hi) in LIMITS.items():
        length = len(str(pin.get(field, "")))
        if not lo <= length <= hi:
            problems.append(f"{field}: {length} characters (needs {lo} to {hi})")
    everything = " ".join(str(pin.get(k, "")) for k in ("overlay", "title", "description", "alt"))
    for phrase in SPAM_PHRASES:
        if phrase in everything.lower():
            problems.append(f'spam-risk phrase "{phrase}"')
    if PRICE.search(everything):
        problems.append("contains a price (pins never carry prices)")
    if str(pin.get("description", "")).count("#") > 3:
        problems.append("more than 3 hashtags in the description")
    return problems


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 1
    with open(sys.argv[1], encoding="utf-8") as f:
        pins = json.load(f)
    seen_titles, failed = set(), False
    for i, pin in enumerate(pins, 1):
        problems = check(pin, i)
        title = str(pin.get("title", "")).strip().lower()
        if title in seen_titles:
            problems.append("same title as an earlier pin")
        seen_titles.add(title)
        if problems:
            failed = True
            print(f"PIN {i}: FIX")
            for p in problems:
                print(f"  - {p}")
        else:
            print(f"PIN {i}: pass")
    print("\nAll pins pass." if not failed else "\nFix the pins marked FIX and run again.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
