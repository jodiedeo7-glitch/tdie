# Writing the image prompt

Every pin gets its own complete prompt. She will paste it into whatever image tool she uses, so it has to stand alone and work in any tool.

## Shape and basics
- Vertical, 2:3 (1000 x 1500).
- Real-photo language: name the light (soft morning window light, warm lamp light), the angle (overhead, eye level, slightly above) and the surface or room.
- Leave a calm, uncluttered area where the words will sit, and say where it is ("clear space across the top third").

## The words on the image are added afterwards
Tell her this in one line under the prompt: "Add the words in Canva or your editor after you make the image." Image tools often misspell or warp lettering, and a pin with a garbled word looks careless. So the prompt itself always says "no text, letters, logos or watermarks anywhere in the image".

## Colour
- Write colours as a name plus a shade: "saturated hot pink, never pale", "warm cream", "lavender, clearly purple, never grey".
- An unqualified colour word comes out washed out. "Pink" alone gives near-white.
- Never put a colour code (like a # code) inside a prompt. Tools print it as visible characters in the picture.
- Use the colours from her Brand File. If none are decided, choose a simple palette that suits the topic and say so.

## People
Check "People in my content" in her Brand File.
- **Never / no people:** flat lays, desks, hands-free scenes, objects, rooms. Say "no people".
- **AI persona from a reference image:** open the prompt with "Photograph of this exact woman from the attached reference image. Identity is taken only from the reference." Then describe only what changes from day to day: what she wears, how her hair is styled, what she is doing, where she is. Never describe her face, hair colour, skin, eye colour, body or age in words; describing them is what makes her look like a different person in each picture. Remind her to attach her reference image.
- **Hands only:** say "hands only, no face in frame".
- **Her real face:** do not write a generated-person prompt. Describe the photo she should take instead (setting, light, angle, what she is holding).

## Keep it safe
- No brand logos, no cartoon or film characters, no celebrity look-alikes.
- Nothing that implies a result: no fake earnings screens, no fake notifications.

## Template
> Vertical 2:3 photograph. [Scene: what is in it, on what surface or in what room]. [Light]. [Camera angle]. [Colours as name plus shade]. [People line from the rules above]. Clear, uncluttered space [where] for a headline to be added later. Realistic, natural, not staged or plastic. No text, letters, logos or watermarks anywhere in the image.
