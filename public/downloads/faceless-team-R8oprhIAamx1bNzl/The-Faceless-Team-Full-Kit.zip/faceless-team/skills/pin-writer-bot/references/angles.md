# Pin angles

Use a different angle for every pin in a batch. Pick the ones that fit the source; do not force all ten.

1. **The list.** A numbered set of things from the source. "7 ..." "5 ..." Works for almost anything and is the easiest to make content-dense.
2. **The steps.** How to do the thing, in order. Words on the image are the steps or the first three.
3. **The checklist.** Tick-box rows the reader can follow. One box shown ticked makes it look usable.
4. **The mistake.** The thing most people get wrong, and what to do instead.
5. **The before and after.** The state she is in now, the state she wants. No invented results.
6. **The question.** The exact question the searcher has in her head, answered in the description.
7. **The time saver.** What this takes off her plate: a task, a decision, an evening.
8. **The beginner start.** "Start here" for someone brand new; removes the fear of not knowing enough.
9. **The single tip.** One specific, slightly surprising tip pulled from the source.
10. **The look inside.** For a product or freebie: what is actually in it, shown plainly (pages, sections, what each does).

Matching angle to source:
- Blog post or guide: 1, 2, 4, 6, 9
- Product she sells: 10, 7, 5, 3, 8
- Freebie: 10, 3, 8, 6
- Affiliate product: 9, 7, 6 (and add the disclosure)
