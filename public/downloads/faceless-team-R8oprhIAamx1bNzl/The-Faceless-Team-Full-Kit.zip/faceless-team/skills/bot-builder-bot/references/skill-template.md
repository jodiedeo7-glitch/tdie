# Template for a bot's SKILL.md

Copy this shape. Replace everything in brackets. Keep the three dashes on their own lines at the top exactly as shown.

```
---
name: [bot-name-in-lowercase-with-hyphens]
description: [One or two sentences on what the bot does and for whom. Then: Use this whenever she says "[phrase a user would type]", "[another]", "[another]", or mentions [topic words], even if she does not say the word "bot".]
---

# [Bot Name]

[Two or three sentences to the AI: who the user is, what the job is, and what a good result looks like. Write it the way you would brief a capable new assistant.]

## Before you start
[What to read first, such as the user's brand file. What to ask if something is missing. Ask in numbered choices plus "type your own", one short round at a time.]

## The steps
1. [First step, and why it matters.]
2. [Second step.]
3. [...]

## What good looks like
[The format of the finished result, exactly as it should be handed over. Include a short template if the result has fixed parts.]

## Rules, each with its reason
- [Rule.] [Because...]
- [Rule.] [Because...]

## Check before you show the user
[If there is a checking script: when to run it and what to do if it fails. If not: the three things to re-read for.]

## Rules that protect the user
- Use only what the user gives you. Never invent facts, numbers, reviews or results.
- Never promise an outcome or how fast it will come.
- [Anything specific to this job: disclosures, "not professional advice", things it must refuse.]
```

## Folder layout

```
bot-name/
  SKILL.md            (required)
  references/         (optional: long examples, lists, templates the bot reads when needed)
  scripts/            (optional: small checking scripts)
```

## Writing tips
- Explain why, not just what. "Keep titles under 100 characters because longer ones get cut off" works better than "TITLES MUST BE UNDER 100 CHARACTERS".
- One job per bot.
- Keep SKILL.md under about 300 lines. Move long material into `references`.
- Include one worked example of a good result. Make it an invented example or her own, never someone else's work.
- Never write a real buyer's private details into a bot.
