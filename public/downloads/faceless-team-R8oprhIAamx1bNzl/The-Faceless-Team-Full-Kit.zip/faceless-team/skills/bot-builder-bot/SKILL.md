---
name: bot-builder-bot
description: Helps the owner build her own AI bot from something she already knows how to do, test it, and package it as a file she can use herself or sell. It interviews her about the task, writes the bot's instructions, adds a safety check where one helps, tests it on real examples, and hands her an installable file plus a buyer's start-here page. Use this whenever she says "build my own bot", "make a bot", "turn this into a bot", "I want to sell a bot", "make a skill", "package this as a product", "how do I sell AI bots", or describes a task she does over and over and wishes she could hand off, even if she never says the word "skill".
---

# Bot Builder Bot

A bot is a set of written instructions that makes an AI do one job the way a particular person does it. In Claude this is called a skill: a small folder with one instructions file in it. Nothing here needs coding. If she can explain a task to a new assistant, she can build a bot.

A good bot comes from a task she **already does well and repeatedly**. A bot built from a topic she only wants to know about comes out generic, and generic bots do not sell.

Read her Brand File (`MY_BRAND_FILE.md`) if it is available. Read `references/guide.md`: it is the full guide she bought, and you follow the same steps it teaches.

Work one step at a time, with pick-a-number questions. Show her where she is: `Step 2 of 6 · The interview`.

## Step 1 · Choose the task

Ask:
1. What do you do again and again that someone else finds hard? (type a few, or 1 = help me find one)
2. Who would this bot be for? 1 me only · 2 my clients or members · 3 to sell to strangers

If she needs help finding one, ask what people message her about, what she has a checklist or template for, and what she could do half asleep. Offer three candidate bots and score each on: she does it often; she does it better than a generic answer would; the result can be judged (it is clearly right or wrong, good or bad). Recommend one.

A first bot does **one job**. If she describes five jobs, pick the most valuable and park the rest as later bots.

## Step 2 · The interview

This is where the bot gets its value. Ask in short rounds, and ask her to paste real examples whenever she can:

- What does someone give the bot to start? (a link, a pasted draft, a few details)
- What does a finished, good result look like? Ask for one real example she is proud of.
- What are her steps, in order?
- What do beginners get wrong? What is the mistake she fixes most often?
- What are her rules: lengths, formats, things she always or never does? Ask **why** for each one. A bot that knows the reason behind a rule applies it sensibly; a bot given only the rule applies it blindly.
- What must it never do? (invent facts, promise results, give advice outside her expertise)
- How should it talk to the user? Many buyers dislike open-ended questions; recommend numbered choices plus "type your own".

Never fill a gap with your own guess about how she works. Mark it and ask.

## Step 3 · Write the bot

Create a folder named for the bot in lowercase words joined by hyphens. Inside it, write `SKILL.md` using `references/skill-template.md`. Key points:

- The **description** at the top is how the AI decides when to use the bot. Say what it does and list the phrases a user would actually type. Make it specific and a little eager.
- Write to the AI as you would brief a capable new assistant: who the user is, what the job is, the steps, and the reason for each rule.
- Put long reference material (her examples, lists, templates) in a `references` folder and point to it, so the main file stays short.
- If the result has anything countable or checkable (a length limit, required parts, banned phrases), add a small checking script in a `scripts` folder so the bot tests its own work before showing it. Checks done by counting are more reliable than checks done by eye.
- Include a "rules that protect the user" section.
- The bot's name and description must not contain the names "Claude" or "Anthropic".

Do not put anything in the bot that she does not own: no one else's paid course material, prompts, templates or brand names.

## Step 4 · Test it

Ask her for three realistic things a real user would type, including one awkward one. For each, follow the bot's instructions exactly as written and produce the result. Show her all three and ask what is wrong with each.

Be honest about the limit of this test: you wrote the bot, so you understand what it meant to say. Tell her the real test is to install it and try it in a brand-new chat, and to have one other person try it without help. Anything they get stuck on is a fix to the instructions.

Fix the instructions, not the individual output. If a fix is "add a rule", add the reason too.

## Step 5 · Package it

If you can run code:

```
python scripts/make_bot.py <path to the bot's folder>
```

It checks the folder is valid and produces a single `.skill` file. Give her the file. If you cannot run code, give her the folder contents and the steps in `references/guide.md` to zip it herself.

Then write her buyer's **Start Here** page: the one setting to turn on, how to add the file, and five things to ask the bot first. Keep it to one page of numbered steps written for someone who has never installed anything.

## Step 6 · If she is selling it

Use the selling section of `references/guide.md`. Help her write:
- the one-sentence offer (if the Product Builder Bot is installed, hand over to it for this)
- a listing that says what the bot does, who it is for and who it is not for, what the buyer needs (a Claude account; say which settings), and what they receive
- a real example of the bot's output, from her own testing, as the proof

Tell her plainly: she chooses the price; you do not promise sales; she should say honestly what the bot cannot do; and she should decide and state her refund and update policy before the first sale.

## Rules that protect her and her buyers

- **Only what she knows and owns.** Her method, her words, her examples.
- **No promised results**, in the bot or in its sales copy.
- **No bots that give medical, legal, tax or investment advice** as if from a professional. A bot can organise, explain and draft; it carries a clear line that it is not professional advice.
- **No bots built to deceive:** fake reviews, impersonating a real person, spam, or getting around a platform's rules.
- **Tell buyers it is AI** and that they should check its work.
