#!/usr/bin/env python3
"""Check a bot folder and package it as a .skill file.

Usage: python make_bot.py <path to the bot folder> [output folder]
Exit code 0 = packaged. 1 = something to fix (nothing is packaged).
"""
import os
import re
import sys
import zipfile


def problems_in(folder):
    problems = []
    name_dir = os.path.basename(os.path.normpath(folder))
    path = os.path.join(folder, "SKILL.md")
    if not os.path.isfile(path):
        return ["there is no SKILL.md file in the folder"], None
    text = open(path, encoding="utf-8").read()
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.DOTALL)
    if not m:
        return ["SKILL.md must start with the name and description between two lines of three dashes"], None
    front = m.group(1)
    name = re.search(r"^name:\s*(.+)$", front, re.MULTILINE)
    desc = re.search(r"^description:\s*(.+)$", front, re.MULTILINE | re.DOTALL)
    if not name:
        problems.append("no name line")
    else:
        n = name.group(1).strip()
        if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", n):
            problems.append("the name must be lowercase letters, numbers and hyphens only")
        if len(n) > 64:
            problems.append("the name is longer than 64 characters")
        if "claude" in n or "anthropic" in n:
            problems.append('the name must not contain "claude" or "anthropic"')
        if n != name_dir:
            problems.append(f'the folder is called "{name_dir}" but the name is "{n}"; they must match')
    if not desc:
        problems.append("no description line")
    else:
        d = desc.group(1).strip()
        if len(d) < 60:
            problems.append("the description is too short to tell the AI when to use the bot")
        if len(d) > 1024:
            problems.append(f"the description is {len(d)} characters (limit 1024)")
        if "<" in d or ">" in d:
            problems.append("the description must not contain angle brackets")
    body = text[m.end():]
    if len(body.strip()) < 200:
        problems.append("the instructions are almost empty")
    if len(body.splitlines()) > 500:
        problems.append("the instructions are over 500 lines; move long material into a references folder")
    return problems, (name.group(1).strip() if name else None)


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    folder = os.path.normpath(sys.argv[1])
    out_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(folder) or "."
    if not os.path.isdir(folder):
        print("That folder does not exist.")
        return 1
    problems, name = problems_in(folder)
    if problems:
        print("FIX before packaging:")
        for p in problems:
            print(f"  - {p}")
        return 1
    out = os.path.join(out_dir, f"{name}.skill")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(folder):
            dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
            for f in files:
                if f.endswith(".pyc") or f == ".DS_Store":
                    continue
                full = os.path.join(root, f)
                z.write(full, os.path.join(name, os.path.relpath(full, folder)))
    print(f"Packaged: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
