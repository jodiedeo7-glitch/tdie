# Writing the posts

Write in her voice from the Brand File. Match her sample sentences, her emoji setting and her "never say" list. These notes are about shape, not tone.

## Every post
- **The first line is the post.** No warm-up ("I've been thinking...", "Hope everyone's having a great week"). If the first line could be deleted and the post still works, delete it.
- Short lines, white space, one idea. A member should be able to read it on a phone in under a minute.
- A title of a few plain words that says what the post is about.
- Never write that members said, asked or did something unless she told you they did. "A few of you asked" is a claim; if it is not true, open another way.

## Teach
1. Name the problem the way a member would say it.
2. Give one thing to do today, small enough to finish in one sitting. A step, not a philosophy.
3. Say what usually goes wrong, or the one question to ask.
4. End with a specific invitation to reply: "paste yours below and I'll tell you what a stranger sees" works; "thoughts?" does not.
No offer, no price, no affiliate link.

## Value
- **Engagement:** one easy question with a low bar to answer. Two rules or fewer.
- **Ritual thread:** the same wording every week so it becomes a habit.
- **Member win:** only one she has given you. Say what the member did, not what they earned, unless she gave you the figure and permission.
- **Free resource:** what it is, who it is for, what they will have after using it, one link behind the words.

## Sell
1. Open with the situation the offer is for, or a real question she has been asked.
2. Say plainly what it is and what is in it. A short list is fine.
3. One price, exactly as in her Brand File. If she has not given you the price, ask; never guess.
4. Any honest fine print she has (no refunds, what it does not include) stated plainly. Plain fine print builds more trust than hiding it.
5. One call to action, link behind the words.
6. Let people off the hook: it is fine to say "if you're good where you are, be good where you are".
Never fake urgency, never a results promise.

## Replies
Answer first. One specific addition. An open door. Three to five short lines. Use the member's name once if she gave it.

## Check-ins for quiet members
One or two lines. A real question. No pitch, no guilt ("we miss you!" reads as a template). Something only she would say.
