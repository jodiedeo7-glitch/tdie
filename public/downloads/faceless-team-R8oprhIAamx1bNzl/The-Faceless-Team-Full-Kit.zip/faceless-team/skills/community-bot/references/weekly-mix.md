# The weekly mix and the spread rules

## The mix

**Three posts a day (21 a week)**
- At least 9 pure Teach posts with no offer
- At least 3 engagement posts (in the Value slot)
- 2 free resources
- About 2 mentions of her main paid step up
- 1 mention of one other offer
- Affiliate posts occasional, never more than one in a day

**Two posts a day (14 a week)**
- 7 Teach, one every day
- 5 Value (at least 2 engagement, 1 free resource, 1 ritual thread)
- 2 Sell

**One post a day (7 a week)**
- 4 Teach
- 2 Value (1 engagement or ritual thread, 1 free resource)
- 1 Sell

## The spread rules

- Teach first, value second, sell third. Selling is never the majority of a week.
- At most one selling post a day, and never two selling posts back to back (the last post of one day and the first of the next count).
- The same offer never runs two days in a row, and not more than twice in a week, unless she tells you a launch or sale window is running.
- Affiliate posts are occasional: never two on the same day or on consecutive days, never the same affiliate product twice in a week, never in the Teach slot, disclosure always in the same post.
- Nothing repeats inside 14 days: topic angle, hook, opening line, image idea or freebie.
- A link to her own free article or lesson is not an offer. It can go at the end of a Teach post behind words like "the long version is here".

## During a real launch or sale window

She tells you the dates. The offer may run more often (about every day and a half), each post from a different angle: what it is, who it is for, the objection most people have, what is inside, the deadline. The Teach posts keep running every day regardless. When the window ends, the normal mix returns.

## Ritual threads

A ritual thread is the same prompt on the same day every week, so members know when to show up. Suggestions if she has none:
- Monday: one thing you will finish this week
- Wednesday: ask anything
- Friday: show your work (say what you want eyes on, and look at two other people's before you post yours)
- Sunday: what did you finish
