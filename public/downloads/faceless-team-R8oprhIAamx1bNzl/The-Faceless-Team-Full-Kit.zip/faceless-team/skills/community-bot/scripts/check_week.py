#!/usr/bin/env python3
"""Check a week of community posts against the spread rules.

Usage: python check_week.py week.json

week.json is a list of posts IN POSTING ORDER. Each post:
  {"day": "Mon", "slot": "teach" | "value" | "sell",
   "title": "...", "offer": "name of the offer or empty",
   "affiliate": true/false, "window": true/false}
"window": true marks a post inside a real launch or sale window she told you about.
Exit code 0 = passes. 1 = something to fix.
"""
import json
import sys
from collections import Counter

DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 1
    with open(sys.argv[1], encoding="utf-8") as f:
        posts = json.load(f)
    problems = []

    def d(p):
        return str(p.get("day", "")).strip().lower()[:3]

    per_day = Counter(d(p) for p in posts)
    posts_per_day = max(per_day.values()) if per_day else 0
    teach = [p for p in posts if p.get("slot") == "teach"]
    sell = [p for p in posts if p.get("slot") == "sell"]

    for p in teach:
        if p.get("offer") or p.get("affiliate"):
            problems.append(f'{p.get("day")}: Teach post "{p.get("title")}" carries an offer or affiliate link')
    if len(sell) > len(posts) / 2:
        problems.append("selling is more than half the week")
    need = {1: 4, 2: 7, 3: 9}.get(posts_per_day, 4)
    if len(teach) < need:
        problems.append(f"only {len(teach)} Teach posts (needs at least {need} at {posts_per_day} a day)")

    sells_by_day = Counter(d(p) for p in sell if not p.get("window"))
    for day, n in sells_by_day.items():
        if n > 1:
            problems.append(f"{day}: {n} selling posts in one day")
    for a, b in zip(posts, posts[1:]):
        if a.get("slot") == "sell" and b.get("slot") == "sell" and not (a.get("window") and b.get("window")):
            problems.append(f'two selling posts back to back: "{a.get("title")}" then "{b.get("title")}"')

    offer_days = {}
    for p in posts:
        if p.get("offer") and not p.get("window"):
            offer_days.setdefault(p["offer"].strip().lower(), []).append(d(p))
    for offer, days in offer_days.items():
        if len(days) > 2:
            problems.append(f'"{offer}" appears {len(days)} times (twice a week at most outside a window)')
        idx = sorted({DAYS.index(x) for x in days if x in DAYS})
        if any(b - a == 1 for a, b in zip(idx, idx[1:])):
            problems.append(f'"{offer}" runs two days in a row')

    aff = [p for p in posts if p.get("affiliate")]
    aff_idx = sorted(DAYS.index(d(p)) for p in aff if d(p) in DAYS)
    if any(b - a <= 1 for a, b in zip(aff_idx, aff_idx[1:])):
        problems.append("affiliate posts on the same day or on consecutive days")

    titles = Counter(str(p.get("title", "")).strip().lower() for p in posts)
    for t, n in titles.items():
        if t and n > 1:
            problems.append(f'title used {n} times: "{t}"')

    if problems:
        print("FIX:")
        for p in problems:
            print(f"  - {p}")
        return 1
    print(f"Week passes: {len(posts)} posts, {len(teach)} teach, {len(sell)} sell.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
