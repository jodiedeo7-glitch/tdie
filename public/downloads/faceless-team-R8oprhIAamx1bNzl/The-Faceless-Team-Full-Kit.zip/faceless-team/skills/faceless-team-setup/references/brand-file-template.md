# MY BRAND FILE

Last updated: [date]

Every Faceless Team bot reads this before it writes anything. To change it, say "update my brand file".

## Who I am
- Brand name: [name, or "not decided yet"]
- Who I help: [her words]
- What I sell: [her words; "nothing yet" if so]
- My main link: [link, or "none yet"]

## How I sound
- My voice: [up to three picks]
- Emojis: [lots / a few / never]
- Never say: [her list]
- Sentences in my own words (match this rhythm and word choice):
  > [her pasted sample, or "none given: keep it plain and conversational"]

## How I show up
- People in my content: [never / AI persona from my reference image / my real face / hands only]
- My colors: [plain words, or "not decided yet"]
- Where I post: [list]
- My Pinterest boards: [list, or "none yet: suggest board names when writing pins"]

## Rules for my team
- Commission links: [yes / no / not sure]. If yes or not sure, add a clear disclosure wherever one of those links appears.
- Use only facts, numbers and results I have actually given you. Never invent proof.
- If a person appears from a reference image, say "this exact woman from the attached reference" and never describe her face, hair colour, skin, body or age in words. Describe only what changes: what she wears, how her hair is styled, what she is doing.
- Never promise a result or how fast it will come.
