# Where to look

Give her only the steps for the platform she uses. Ten minutes, once a week.

## Instagram
1. Search a phrase her buyer would type (her niche in plain words). Open the Reels tab of the results.
2. Open any Reel that seems to have far more views than you would expect. Tap through to the account.
3. Check the account is small or mid-sized and in her niche. Skip celebrities, big brands and accounts of a different kind.
4. Screenshot the Reel, then screenshot the account's Reels grid so the view counts on its other Reels are visible.
5. Tap the sound name on a good Reel to see other Reels using it. Good ones often share a sound.
6. When the same phrase keeps showing up in on-screen text, search that exact phrase.
7. Look at who comments on a good post. They are often the same kind of creator, and worth checking.

## TikTok
1. Search her niche phrase and open the Videos tab.
2. Same checks: a video far above what the account normally gets, a small account in her niche.
3. Screenshot the video and the account's grid.
4. Tap the sound, and search any repeated phrase.
Trends often show up here a week or two before they reach Instagram.

## Pinterest
1. Search her keyword. Look at what fills the top of the results.
2. Open the pins that look like they come from small accounts. Note the pin's format (list, checklist, steps, photo), the words on it and the title.
3. Pinterest hides most numbers, so qualify on position and repetition: a format that appears again and again at the top for her keywords is the finding. Label Pinterest findings as "ranking patterns", not outliers.

## Facebook groups and communities
1. Sort a busy group in her niche by recent activity.
2. Look for posts with far more comments than that group's normal posts.
3. Note the opening line, the question asked and what people argued or agreed about.

## Bringing it back
A screenshot of the post and a screenshot of the account's grid is enough. She should not type numbers out by hand unless she wants to. Aim for ten posts from at least six different accounts the first week, then five new ones each week.
