# Finding the patterns

This is analysis, not a tally. For every outlier, answer: what stopped the scroll, and what made people respond in the way the platform rewards (sends, shares, saves, comments, follows, rewatches)? Then compare with that account's ordinary posts. If the ordinary posts used the same trick and did nothing, the trick was not the reason.

## What to classify

**The hook type.** Label each, and count per type:
- pain point ("you're posting every day and nobody sees it")
- curiosity gap ("I changed one thing")
- fear of missing out ("everyone in this niche is doing this now")
- shock or contradiction ("stop posting Reels")
- call-out ("small accounts, this is for you")
- confession ("I only have 41 followers")
- a trade or direct ask ("send me this and I'll...")
- a challenge or dare
- relatability ("if you know, you know")
- a number or list promise

**Catchy or interrupting.** Catchy is easy to repeat. Interrupting breaks the scroll: a blank frame, a whisper, an odd first second. Record what the interruption actually was.

**Repeated phrases.** Any opener or on-screen phrase appearing three or more times across different accounts, with the count.

**Repeated post types.** Text-only Reels, day-in-the-life, before and after, screen recordings, get-ready-with-me, follow-back trades. Count them. The same type winning on accounts that never win is the strongest finding there is.

**The response.** What did people actually do: send it, tag someone, comment a word, follow, argue? A shared post and an argued-with post work for different reasons.

**The ask**, and which ask produced which response.

**Format and length**, and where in the clip the hook lands.

**Who is in the frame.** Keep two separate counts and never blur them: how many had a person at all (face, back, hands or feet all count), and how many showed a face. "No face" is not "no person".

**The words on screen:** how many, where, what style.

**The sound**, and whether several outliers share one.

**The caption's first line.**

**Day and time**, where visible.

## How to write a finding
- A plain claim with the count: "9 of 14 used plain white text typed in the app, centred; none used a designed graphic."
- Fewer than five posts behind it: label it a hunch.
- Say what the controls did. "The same accounts' ordinary posts asked for nothing" is half the finding.
- Never round up, never say "most" without the number.

## Turning findings into her week
- Decide how many posts are pure reach (no offer) and how many carry an offer. Reach posts follow the patterns; offer posts keep the offer to the last line of the caption.
- One pattern per post. Tag it.
- Give each idea its own words, written for her niche and her life. If a hundred people will see the same research, their posts must not come out identical.
