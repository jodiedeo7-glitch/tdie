#!/usr/bin/env python3
"""Outlier arithmetic and the swipe file.

Check a post:
  python outlier.py check <post_views> <followers> <other1> <other2> ...
  (the "others" are views on the account's other recent posts; give about twelve.
   Use the word hidden for <followers> if it is not shown.)

Add a qualified post to the swipe file:
  python outlier.py add MY_SWIPE_FILE.csv <date YYYY-MM-DD> "<account>" <followers> <views> <normal>
      "<platform>" "<hook type>" "<on-screen words>" "<ask>" "<who is in frame>" "<note>"

Summarise the swipe file:
  python outlier.py summary MY_SWIPE_FILE.csv
"""
import csv
import os
import statistics
import sys
from collections import Counter

HEAD = ["date", "account", "followers", "views", "normal", "ratio", "platform",
        "hook_type", "on_screen_words", "ask", "in_frame", "note"]


def to_num(x):
    try:
        return float(str(x).replace(",", ""))
    except ValueError:
        return None


def check(args):
    views = to_num(args[0])
    followers = to_num(args[1])
    others = [to_num(a) for a in args[2:]]
    others = [o for o in others if o is not None]
    if views is None or not others:
        print("Need the post's views and the views on the account's other recent posts.")
        return 1
    normal = statistics.median(others)
    ratio = views / normal if normal else float("inf")
    print(f"Account's normal (median of {len(others)} posts): {normal:.0f}")
    print(f"This post: {views:.0f}  =  {ratio:.1f} times normal")
    if len(others) < 6:
        print("Note: fewer than six other posts given, so the normal is rough.")
    ok = ratio >= 5
    if followers:
        fr = views / followers
        print(f"Views are {fr:.1f} times the follower count ({followers:.0f})")
        ok = ok or fr >= 10
    print("QUALIFIES as an outlier." if ok else
          "Does NOT qualify on views (needs 5 times normal or 10 times followers). "
          "It can still qualify on engagement far above the account's normal.")
    return 0


def add(args):
    path, rest = args[0], args[1:]
    if len(rest) != 11:
        print("Give all eleven fields after the file name (see the header of this script).")
        return 1
    date, account, followers, views, normal = rest[:5]
    v, n = to_num(views), to_num(normal)
    ratio = f"{v / n:.1f}" if v is not None and n else "hidden"
    new = not os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new:
            w.writerow(HEAD)
        w.writerow([date, account, followers, views, normal, ratio] + rest[5:])
    print("Added.")
    return 0


def summary(args):
    with open(args[0], newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    n = len(rows)
    print(f"{n} posts from {len({r['account'] for r in rows})} accounts")
    if n < 10:
        print("Fewer than ten posts: treat every pattern as a hunch for now.")
    for field, label in (("hook_type", "Hook types"), ("ask", "Asks"),
                         ("in_frame", "Who is in the frame"), ("platform", "Platforms")):
        c = Counter((r.get(field) or "not recorded").strip().lower() for r in rows)
        print(f"\n{label}:")
        for k, v in c.most_common():
            tag = "" if v >= 5 else "  (hunch: fewer than five)"
            print(f"  {v} of {n}: {k}{tag}")
    return 0


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    cmd, args = sys.argv[1], sys.argv[2:]
    if cmd == "check":
        return check(args)
    if cmd == "add":
        return add(args)
    if cmd == "summary":
        return summary(args)
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main())
