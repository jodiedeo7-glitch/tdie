# The one-sentence offer

If she cannot say what she sells in one sentence, her buyer cannot repeat it to a friend, and nobody buys what they cannot explain to themselves. Almost every beginner makes the same mistake: she leads with what she made instead of what the buyer gets.

## The three parts, in this order

1. **Who she is.** The buyer, specific enough that the wrong person knows it is not for her.
2. **What she walks away with.** The state she is in afterwards, not the thing she is handed.
3. **What it costs her to get there.** Time, effort, or the thing she no longer has to do.

The format, the price and the list of what is inside all go underneath, in the second sentence or later. Underneath is not nowhere. It is just not first.

## The four checks

Run all four out loud on every version, and show pass or fail for each:

1. **Does it start with the buyer, or with the seller?** If it opens with "I created", "I offer" or "I help you get", rewrite it.
2. **Does it name a format or a length?** ("a 20-page guide", "a 60-minute session") Move that to the second sentence.
3. **Does it contain a price?** Move it.
4. **Could she repeat it to a friend from memory after reading it once?** If not, it is too long.

## The five ways it goes wrong

Name which one a weak sentence is, because naming it is what makes the fix stick.

1. **Selling the container, not the contents.** She describes the session, the guide, the bundle. The buyer wants what happens after it.
2. **Burying the surprising part.** The one thing that makes this different is sitting at the end of the sentence. Say it first, explain it second.
3. **Listing what is inside instead of what it saves her.** An inventory says what is in the box. It does not say what the buyer stops doing.
4. **Naming the person and stopping there.** "Printables for overwhelmed moms" names her but never says what happens.
5. **Starting the sentence with yourself.** "I created..." Start where the buyer is.

## Worked pattern (invented example, for shape only)

Weak: "I created a 12-page meal planning guide with shopping lists and recipes for busy families."
Fails check 1 (starts with the seller) and check 2 (names a format). Failure type 3: an inventory.

Stronger: "Busy parents get a week of dinners decided in ten minutes, so 5 pm stops being a panic."
Who: busy parents. Walks away with: a week of dinners decided. Costs her: ten minutes.
Then underneath: "It's a 12-page guide with shopping lists and recipes."

## Where the sentence goes

The same sentence, word for word, in three places: the first line of the sales page, her shop bio, and her link-in-bio. If the three do not match, she has three offers and the buyer picks none.
