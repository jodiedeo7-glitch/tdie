# First-product formats

Smallest first. Recommend the smallest format that solves the problem.

| Format | Best when | Typical size | What you need from her |
|---|---|---|---|
| Checklist | The buyer keeps forgetting steps | 1 to 3 pages | Her steps, in order, and the one people skip |
| Cheat sheet | The buyer keeps looking the same thing up | 1 to 2 pages | The facts or settings she uses every time |
| Template or script pack | The buyer faces a blank page | 5 to 10 items | Real ones she has used, lightly cleaned up |
| Short guide | The buyer needs the "why" plus the steps | 8 to 15 pages | Her process, her mistakes, one real example |
| Planner or tracker | The buyer needs to do it repeatedly | 3 to 10 pages | What she tracks and how often |
| Prompt pack | The buyer uses AI but gets generic answers | 10 to 25 prompts | The prompts she actually uses, with what to fill in |
| Mini workbook | The buyer needs to make decisions | 8 to 15 pages | The questions she asks and what each answer leads to |

Rules of thumb:
- One problem, one person, one format.
- If she wants a course or a membership as her first product, suggest starting with the single most useful piece of it in one of the formats above. It gets finished, and it tells her whether people want the bigger thing.
- A product made from templates or prompts must be her own. Nothing copied from another seller.
