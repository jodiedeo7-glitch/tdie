# Sales page

Short, honest, specific. Write it in her voice from the Brand File. Order:

1. **Headline:** the one-sentence offer, word for word.
2. **The moment she is in.** Two or three lines describing the buyer's situation the way she would say it herself. Specific scenes beat general pain ("it's 5 pm and nothing is defrosted").
3. **What changes.** What she will be able to do after using it. Abilities and relief, never income or guaranteed outcomes.
4. **What's inside.** A plain list: each item plus what it does for her. This is where the format, page count and contents live.
5. **Who it's for, and who it isn't.** Telling the wrong buyer to skip it makes the right one trust the page.
6. **Why her.** One or two true sentences about how the seller learned this. Only facts she has given.
7. **Proof.** Only real proof she supplies. If she has none yet, leave the section out. Never invent a review or a number.
8. **Price and button.** The price she chose, what she receives and how (instant download), and one clear button line.
9. **Small print she needs.** Refund policy in her own terms; a one-line "not professional advice" note for health, legal or money topics.

Leave out: countdown timers that are not real, "only 3 left" on a digital file, fake discounts, results timelines.
