# Usage: python3 render.py <bundle folder>   (photos must be in ph/basic.png styled.png lifestyle.png roundup.png foundit.png)
import sys, os
from playwright.sync_api import sync_playwright
S=os.path.abspath(sys.argv[1])
with sync_playwright() as p:
    exe='/usr/bin/google-chrome' if os.path.exists('/usr/bin/google-chrome') else None
    b=p.chromium.launch(executable_path=exe, args=['--allow-file-access-from-files'])
    pg=b.new_page(viewport={'width':1080,'height':2160})
    pg.goto('file://'+S+'/flyer.html'); pg.wait_for_timeout(1500)
    print('fonts ok:', pg.evaluate("document.fonts.check('700 40px Caveat')&&document.fonts.check('40px Gloock')&&document.fonts.check('600 40px Jost')"))
    print('photos loaded:', pg.evaluate("[...document.querySelectorAll('.pol img')].map(i=>i.getAttribute('src')+' '+i.naturalWidth+'x'+i.naturalHeight)"))
    pg.screenshot(path=S+'/flyer.png'); b.close()
from PIL import Image
im=Image.open(S+'/flyer.png')
im.resize((540,1080)).save(S+'/check_phone.png')
for i,(a,c) in enumerate([(0,720),(420,1020),(920,1660),(1600,2160)]): im.crop((0,a,1080,c)).save(S+f'/check_{i}.png')
print('saved flyer.png and check images')
